 package jmetal.problems.AdaptiveInterface;


/**
 * 
 */


import java.util.Random;
import java.util.Vector;

/**
 * @author User
 *
 */
public class Input {

	/**
	 * @param args
	 * @return 
	 * @return 
	 */

	public static  String[] Metrics() {
		String [] Metrics= { "Regularity",
				"Grouping",
				"Sequence",
				"Simplicity",
				"Unity",
				"Density",
				"Economy",
				"Balance", 
				"Layout uniformity",
				"Homogeneity",
				"Cohesion",
				"Nbelements",
				"Integrality"
				};
	
		
		return Metrics;

	}
	public static  String[] Operator() {
		String [] Operator= { "<=",">="};
	
		
		return Operator;

	}
	public static  String[] AndOr() {
		String [] AndOr= { "&","||"};
	
		
		return AndOr;

	}
	public static  String Val_Metric() {
		Random number_generator = new Random();
		double source_indx = number_generator.nextDouble();
    	double sourc_index=(double)((int)( source_indx *100))/100;
	    String Val_Metric = Double.toString(sourc_index);
		
		return Val_Metric;

	}

	public static  String[] Problem() {
		String [] Problem= { "ILW","ICM","OM","IM"};
	
		
		return Problem;

	}
	

}
