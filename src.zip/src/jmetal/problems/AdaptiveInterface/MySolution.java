package jmetal.problems.AdaptiveInterface;

import java.io.File;




import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

import jmetal.core.Solution;
import jmetal.core.SolutionSet;
import jmetal.encodings.solutionType.IntSolutionType;
import jmetal.problems.Adapt_Interface;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

public class MySolution {
	public String src;
	public String src0;
	public String src2;
	public String src4;
	public String trg;
	public ArrayList<Rule> rules = new ArrayList<Rule> ();
	public ArrayList<Rule2m> rules2 = new ArrayList<Rule2m> ();
	public ArrayList<Rule3m> rules3 = new ArrayList<Rule3m> ();
	public ArrayList<Rule4m> rules4 = new ArrayList<Rule4m> ();
	public ArrayList<Rule5m> rules5 = new ArrayList<Rule5m> ();
	public static ArrayList<Integer> ind2 = new ArrayList<Integer>();
	public static ArrayList<Integer> ind3 = new ArrayList<Integer>();
	public static int NumberOfVaraibles ;
	int min_rules_size = 20;
	int max_rules_size = 30; 
	static ArrayList<Rule> sol = new ArrayList<Rule> ();
	static ArrayList <Rule> parent1 = new  ArrayList <Rule> ();
    static ArrayList <Rule> parent2 = new  ArrayList <Rule> ();

	ArrayList<String> perfect_rule = new ArrayList<String>();
	int source_indexM;//metric
	int source_indexO;//operator
	int source_indexAO;//and or
	
	int target_index;
	Random number_generator = new Random();
	public ArrayList<Rule> create_rules2(Input r, int rules_size) {
		
		int NB_metrics;
		int target_index;
	
		

		for (int i = 0; i < rules_size; i++) {
			NB_metrics= number_generator.nextInt(Input.Metrics().length);
			//ind2.add(source_indexM);
			if (NB_metrics==1){
			source_indexM = number_generator.nextInt(Input.Metrics().length);
			ind2.add(source_indexM);
			source_indexO = number_generator.nextInt(Input.Operator().length);
			
			target_index = number_generator.nextInt(Input.Problem().length);
			ind3.add(target_index);
			
			Rule temp = new Rule();
			
			temp.src = Input.Metrics()[source_indexM];
			temp.src0 = Input.Operator()[source_indexO];
			temp.src1 = Input.Val_Metric();
			temp.trg = Input.Problem()[target_index];
		

			temp.print_rule();
			rules.add(temp);
			
			System.out.println(temp.rule_text);}
			if (NB_metrics==2){
				
				source_indexM = number_generator.nextInt(Input.Metrics().length);
				ind2.add(source_indexM);
				source_indexO = number_generator.nextInt(Input.Operator().length);
				source_indexAO=number_generator.nextInt(Input.AndOr().length);
				int source_indexM1 = number_generator.nextInt(Input.Metrics().length);
				int source_indexO1 = number_generator.nextInt(Input.Operator().length);
			
				target_index = number_generator.nextInt(Input.Problem().length);
				ind3.add(target_index);
				
				Rule2m temp = new Rule2m();
				
				temp.src = Input.Metrics()[source_indexM];
				temp.src0 = Input.Operator()[source_indexO];
				temp.src1 = Input.Val_Metric();
				temp.src2=Input.AndOr()[source_indexAO];
				temp.src3 = Input.Metrics()[source_indexM1];
				temp.src4 = Input.Operator()[source_indexO1];
				temp.src5 = Input.Val_Metric();
				
				temp.trg = Input.Problem()[target_index];
			

				temp.print_rule();
				rules2.add(temp);
				
				System.out.println(temp.rule_text);}
				
			if (NB_metrics==3){
				
				source_indexM = number_generator.nextInt(Input.Metrics().length);
				ind2.add(source_indexM);
				source_indexO = number_generator.nextInt(Input.Operator().length);
				source_indexAO=number_generator.nextInt(Input.AndOr().length);
				int source_indexM1 = number_generator.nextInt(Input.Metrics().length);
				int source_indexO1 = number_generator.nextInt(Input.Operator().length);
				int source_indexAO1=number_generator.nextInt(Input.AndOr().length);
				int source_indexM2 = number_generator.nextInt(Input.Metrics().length);
				int source_indexO2 = number_generator.nextInt(Input.Operator().length);
				target_index = number_generator.nextInt(Input.Problem().length);
				ind3.add(target_index);
				
				Rule3m temp = new Rule3m();
				
				temp.src = Input.Metrics()[source_indexM];
				temp.src0 = Input.Operator()[source_indexO];
				temp.src1 = Input.Val_Metric();
				temp.src2=Input.AndOr()[source_indexAO];
				temp.src3 = Input.Metrics()[source_indexM1];
				temp.src4 = Input.Operator()[source_indexO1];
				temp.src5 = Input.Val_Metric();
				temp.src6=Input.AndOr()[source_indexAO1];
				temp.src7 = Input.Metrics()[source_indexM2];
				temp.src8 = Input.Operator()[source_indexO2];
				temp.src9 = Input.Val_Metric();
				temp.trg = Input.Problem()[target_index];
			

				temp.print_rule();
				rules3.add(temp);
				
				System.out.println(temp.rule_text);}
				
			if (NB_metrics==4){
				
				
				source_indexM = number_generator.nextInt(Input.Metrics().length);
				ind2.add(source_indexM);
				source_indexO = number_generator.nextInt(Input.Operator().length);
				source_indexAO=number_generator.nextInt(Input.AndOr().length);
				int source_indexM1 = number_generator.nextInt(Input.Metrics().length);
				int source_indexO1 = number_generator.nextInt(Input.Operator().length);
				int source_indexAO1=number_generator.nextInt(Input.AndOr().length);
				int source_indexM2 = number_generator.nextInt(Input.Metrics().length);
				int source_indexO2 = number_generator.nextInt(Input.Operator().length);
				int source_indexAO2=number_generator.nextInt(Input.AndOr().length);
				int source_indexM3 = number_generator.nextInt(Input.Metrics().length);
				int source_indexO3 = number_generator.nextInt(Input.Operator().length);
				target_index = number_generator.nextInt(Input.Problem().length);
				ind3.add(target_index);
				
				Rule4m temp = new Rule4m();
				
				temp.src = Input.Metrics()[source_indexM];
				temp.src0 = Input.Operator()[source_indexO];
				temp.src1 = Input.Val_Metric();
				temp.src2=Input.AndOr()[source_indexAO];
				temp.src3 = Input.Metrics()[source_indexM1];
				temp.src4 = Input.Operator()[source_indexO1];
				temp.src5 = Input.Val_Metric();
				temp.src6=Input.AndOr()[source_indexAO1];
				temp.src7 = Input.Metrics()[source_indexM2];
				temp.src8 = Input.Operator()[source_indexO2];
				temp.src9 = Input.Val_Metric();
				temp.src10=Input.AndOr()[source_indexAO2];
				temp.src11 = Input.Metrics()[source_indexM3];
				temp.src12 = Input.Operator()[source_indexO3];
				temp.src13 = Input.Val_Metric();
				temp.trg = Input.Problem()[target_index];
			

				temp.print_rule();
				rules4.add(temp);
				
				System.out.println(temp.rule_text);}
				
			
			if (NB_metrics==5){	
				source_indexM = number_generator.nextInt(Input.Metrics().length);
				ind2.add(source_indexM);
				source_indexO = number_generator.nextInt(Input.Operator().length);
				source_indexAO=number_generator.nextInt(Input.AndOr().length);
				int source_indexM1 = number_generator.nextInt(Input.Metrics().length);
				int source_indexO1 = number_generator.nextInt(Input.Operator().length);
				int source_indexAO1=number_generator.nextInt(Input.AndOr().length);
				int source_indexM2 = number_generator.nextInt(Input.Metrics().length);
				int source_indexO2 = number_generator.nextInt(Input.Operator().length);
				int source_indexAO2=number_generator.nextInt(Input.AndOr().length);
				int source_indexM3 = number_generator.nextInt(Input.Metrics().length);
				int source_indexO3 = number_generator.nextInt(Input.Operator().length);
				int source_indexAO3=number_generator.nextInt(Input.AndOr().length);
				int source_indexM4 = number_generator.nextInt(Input.Metrics().length);
				int source_indexO4 = number_generator.nextInt(Input.Operator().length);
				target_index = number_generator.nextInt(Input.Problem().length);
				ind3.add(target_index);
				
				Rule5m temp = new Rule5m();
				
				temp.src = Input.Metrics()[source_indexM];
				temp.src0 = Input.Operator()[source_indexO];
				temp.src1 = Input.Val_Metric();
				temp.src2=Input.AndOr()[source_indexAO];
				temp.src3 = Input.Metrics()[source_indexM1];
				temp.src4 = Input.Operator()[source_indexO1];
				temp.src5 = Input.Val_Metric();
				temp.src6=Input.AndOr()[source_indexAO1];
				temp.src7 = Input.Metrics()[source_indexM2];
				temp.src8 = Input.Operator()[source_indexO2];
				temp.src9 = Input.Val_Metric();
				temp.src10=Input.AndOr()[source_indexAO2];
				temp.src11 = Input.Metrics()[source_indexM3];
				temp.src12 = Input.Operator()[source_indexO3];
				temp.src13 = Input.Val_Metric();
				temp.src14=Input.AndOr()[source_indexAO3];
				temp.src15 = Input.Metrics()[source_indexM4];
				temp.src16 = Input.Operator()[source_indexO4];
				temp.src17 = Input.Val_Metric();
				temp.trg = Input.Problem()[target_index];
			

				temp.print_rule();
				rules5.add(temp);
				
				System.out.println(temp.rule_text);}
	
		}	return rules ;}

/*	
	///////rule 1 metric
	public ArrayList<Rule> create_rule1(Input input, int rules_size) {

		for (int i = 0; i < rules_size; i++) {
		
		source_indexM = number_generator.nextInt(Input.Metrics().length);
		ind2.add(source_indexM);
		source_indexO = number_generator.nextInt(Input.Operator().length);
		
		target_index = number_generator.nextInt(Input.Problem().length);
		ind3.add(target_index);
		
		Rule temp = new Rule();
		
		temp.src = Input.Metrics()[source_indexM];
		temp.src0 = Input.Operator()[source_indexO];
		temp.src1 = Input.Val_Metric();
		temp.trg = Input.Problem()[target_index];
	

		temp.print_rule();
		rules.add(temp);
		}
		//System.out.println(temp.rule_text);
		return rules;
		
	}
	
	//////rule2metrics
	public ArrayList<Rule2m> create_rule2(Input input, int rules_size) {

		for (int i = 0; i < rules_size; i++) {
		
		
		source_indexM = number_generator.nextInt(Input.Metrics().length);
		ind2.add(source_indexM);
		source_indexO = number_generator.nextInt(Input.Operator().length);
		source_indexAO=number_generator.nextInt(Input.AndOr().length);
		int source_indexM1 = number_generator.nextInt(Input.Metrics().length);
		int source_indexO1 = number_generator.nextInt(Input.Operator().length);
	
		target_index = number_generator.nextInt(Input.Problem().length);
		ind3.add(target_index);
		
		Rule2m temp = new Rule2m();
		
		temp.src = Input.Metrics()[source_indexM];
		temp.src0 = Input.Operator()[source_indexO];
		temp.src1 = Input.Val_Metric();
		temp.src2=Input.AndOr()[source_indexAO];
		temp.src3 = Input.Metrics()[source_indexM1];
		temp.src4 = Input.Operator()[source_indexO1];
		temp.src5 = Input.Val_Metric();
		
		temp.trg = Input.Problem()[target_index];
	

		temp.print_rule();
		rules2.add(temp);
		}
		//System.out.println(temp.rule_text);
		return rules2;
		
	}
	
	
//////rule3metrics
	public ArrayList<Rule3m> create_rule3(Input input, int rules_size) {

		for (int i = 0; i < rules_size; i++) {
		
		source_indexM = number_generator.nextInt(Input.Metrics().length);
		ind2.add(source_indexM);
		source_indexO = number_generator.nextInt(Input.Operator().length);
		source_indexAO=number_generator.nextInt(Input.AndOr().length);
		int source_indexM1 = number_generator.nextInt(Input.Metrics().length);
		int source_indexO1 = number_generator.nextInt(Input.Operator().length);
		int source_indexAO1=number_generator.nextInt(Input.AndOr().length);
		int source_indexM2 = number_generator.nextInt(Input.Metrics().length);
		int source_indexO2 = number_generator.nextInt(Input.Operator().length);
		target_index = number_generator.nextInt(Input.Problem().length);
		ind3.add(target_index);
		
		Rule3m temp = new Rule3m();
		
		temp.src = Input.Metrics()[source_indexM];
		temp.src0 = Input.Operator()[source_indexO];
		temp.src1 = Input.Val_Metric();
		temp.src2=Input.AndOr()[source_indexAO];
		temp.src3 = Input.Metrics()[source_indexM1];
		temp.src4 = Input.Operator()[source_indexO1];
		temp.src5 = Input.Val_Metric();
		temp.src6=Input.AndOr()[source_indexAO1];
		temp.src7 = Input.Metrics()[source_indexM2];
		temp.src8 = Input.Operator()[source_indexO2];
		temp.src9 = Input.Val_Metric();
		temp.trg = Input.Problem()[target_index];
	

		temp.print_rule();
		rules3.add(temp);
		}
		//System.out.println(temp.rule_text);
		return rules3;
		
	}
	
	
	
//////rule4metrics
	public ArrayList<Rule4m> create_rule4(Input input, int rules_size) {

		for (int i = 0; i < rules_size; i++) {
		source_indexM = number_generator.nextInt(Input.Metrics().length);
		ind2.add(source_indexM);
		source_indexO = number_generator.nextInt(Input.Operator().length);
		source_indexAO=number_generator.nextInt(Input.AndOr().length);
		int source_indexM1 = number_generator.nextInt(Input.Metrics().length);
		int source_indexO1 = number_generator.nextInt(Input.Operator().length);
		int source_indexAO1=number_generator.nextInt(Input.AndOr().length);
		int source_indexM2 = number_generator.nextInt(Input.Metrics().length);
		int source_indexO2 = number_generator.nextInt(Input.Operator().length);
		int source_indexAO2=number_generator.nextInt(Input.AndOr().length);
		int source_indexM3 = number_generator.nextInt(Input.Metrics().length);
		int source_indexO3 = number_generator.nextInt(Input.Operator().length);
		target_index = number_generator.nextInt(Input.Problem().length);
		ind3.add(target_index);
		
		Rule4m temp = new Rule4m();
		
		temp.src = Input.Metrics()[source_indexM];
		temp.src0 = Input.Operator()[source_indexO];
		temp.src1 = Input.Val_Metric();
		temp.src2=Input.AndOr()[source_indexAO];
		temp.src3 = Input.Metrics()[source_indexM1];
		temp.src4 = Input.Operator()[source_indexO1];
		temp.src5 = Input.Val_Metric();
		temp.src6=Input.AndOr()[source_indexAO1];
		temp.src7 = Input.Metrics()[source_indexM2];
		temp.src8 = Input.Operator()[source_indexO2];
		temp.src9 = Input.Val_Metric();
		temp.src10=Input.AndOr()[source_indexAO2];
		temp.src11 = Input.Metrics()[source_indexM3];
		temp.src12 = Input.Operator()[source_indexO3];
		temp.src13 = Input.Val_Metric();
		temp.trg = Input.Problem()[target_index];
	

		temp.print_rule();
		rules4.add(temp);
		}
		//System.out.println(temp.rule_text);
		return rules4;
		
	}
	
	
	
	
//////rule5metrics
	public ArrayList<Rule5m> create_rule5(Input input, int rules_size) {

		for (int i = 0; i < rules_size; i++) {
		
		source_indexM = number_generator.nextInt(Input.Metrics().length);
		ind2.add(source_indexM);
		source_indexO = number_generator.nextInt(Input.Operator().length);
		source_indexAO=number_generator.nextInt(Input.AndOr().length);
		int source_indexM1 = number_generator.nextInt(Input.Metrics().length);
		int source_indexO1 = number_generator.nextInt(Input.Operator().length);
		int source_indexAO1=number_generator.nextInt(Input.AndOr().length);
		int source_indexM2 = number_generator.nextInt(Input.Metrics().length);
		int source_indexO2 = number_generator.nextInt(Input.Operator().length);
		int source_indexAO2=number_generator.nextInt(Input.AndOr().length);
		int source_indexM3 = number_generator.nextInt(Input.Metrics().length);
		int source_indexO3 = number_generator.nextInt(Input.Operator().length);
		int source_indexAO3=number_generator.nextInt(Input.AndOr().length);
		int source_indexM4 = number_generator.nextInt(Input.Metrics().length);
		int source_indexO4 = number_generator.nextInt(Input.Operator().length);
		target_index = number_generator.nextInt(Input.Problem().length);
		ind3.add(target_index);
		
		Rule5m temp = new Rule5m();
		
		temp.src = Input.Metrics()[source_indexM];
		temp.src0 = Input.Operator()[source_indexO];
		temp.src1 = Input.Val_Metric();
		temp.src2=Input.AndOr()[source_indexAO];
		temp.src3 = Input.Metrics()[source_indexM1];
		temp.src4 = Input.Operator()[source_indexO1];
		temp.src5 = Input.Val_Metric();
		temp.src6=Input.AndOr()[source_indexAO1];
		temp.src7 = Input.Metrics()[source_indexM2];
		temp.src8 = Input.Operator()[source_indexO2];
		temp.src9 = Input.Val_Metric();
		temp.src10=Input.AndOr()[source_indexAO2];
		temp.src11 = Input.Metrics()[source_indexM3];
		temp.src12 = Input.Operator()[source_indexO3];
		temp.src13 = Input.Val_Metric();
		temp.src14=Input.AndOr()[source_indexAO3];
		temp.src15 = Input.Metrics()[source_indexM4];
		temp.src16 = Input.Operator()[source_indexO4];
		temp.src17 = Input.Val_Metric();
		temp.trg = Input.Problem()[target_index];
	

		temp.print_rule();
		rules5.add(temp);
		}
	
		//System.out.println(temp.rule_text);
		return rules5;
		
	}
	*/
	
	
	////end rules creation
	
	
	
	
	
	
	
	
	
	
	
	/*public void create_solution(Input r, int value) {
		int rules_size;
		int source_index;
		int source_index0;
		//int source_index1;
		//int source_index2;
		int target_index;
		Random number_generator = new Random();
		for (int i = 0; i < value; i++) {
			//source_index = number_generator.nextInt(Input.Context().length);
			//ind1.add(source_index);
			//source_index0 = number_generator.nextInt(Input.ValuesOfContext().length);
			source_index = number_generator.nextInt(Input.Metrics().length);
			ind2.add(source_index);
			source_index0 = number_generator.nextInt(Input.Operator().length);
			target_index = number_generator.nextInt(Input.Problem().length);
			ind3.add(target_index);
			// System.out.println(source_index1);
			Rule temp = new Rule();
			//temp.src = Input.Context()[source_index];
			//temp.src0 = Input.ValuesOfContext()[source_index0];
			temp.src = Input.Metrics()[source_index];
			temp.src0 = Input.Operator()[source_index0];
			temp.src1 = Input.Val_Metric();
			temp.trg = Input.Problem()[target_index];
			// print_metamodel(temp.src,temp.src0,temp.src2,temp.trg);

			temp.print_rule();
			//rules.add(temp);
			System.out.println(temp.rule_text);
		}
		
	}*/
	
	
	public void Mymutation(int value , Rule rule)
	 {   
		
		Random number_generator = new Random();
	      int nb =1;
	    nb = (int) (Math.random() * 2 ); 
	     // System.out.println("nombre � choisir : "+nb);
	      System.out.println("mutation point: "+value);
	      //System.out.println("size of list : "+IntSolutionType.rules.size());
	   if (nb==0)
	      {System.out.println("#####################"+rule.rule_text);
	      Rule temp = new Rule();
	    
	      int source_index0 = number_generator.nextInt(Input.Operator().length);
	      int source_index4 = number_generator.nextInt(Input.Val_Metric().length());  
	
	      rule.src0 = Input.Operator()[source_index0];
	      rule.src1 = Input.Val_Metric();
	      IntSolutionType.Listrules.set(value, rule);
	     
	      }
	      if ( nb==1)
	    	  
	      {System.out.println("*******************"+rule.rule_text);
	    	  
	    	  //IntSolutionType.rules.remove(IntSolutionType.rules.get(value))  ;
	      IntSolutionType.Listrules.remove(rule);
	    
	      }
	  
	      //for(int i=0;i<rules.size();i++){System.out.println("*******"+rules.get(i).rule_text);}
	 } 
	public Rule [] MyCrossover (ArrayList<Rule> parent1, ArrayList<Rule> parent2 , int min_rules_size )
	{
			
			
		
		    Rule Tab [] = new  Rule [2] ;
			
			Rule temp_rule = new Rule();
			ArrayList<Rule> Array_temp = new ArrayList<Rule>();
			ArrayList<Rule> Array_temp2 = new ArrayList<Rule>();
			
			for (int j = 0; j < min_rules_size-1 ; j++){ 
				temp_rule = parent1.get(j);
				Array_temp.add(temp_rule);
				}
			for (int j = 0; j < min_rules_size-1 ; j++){ 
				temp_rule = parent2.get(j);
				Array_temp2.add(temp_rule);
				}
			for(int h= 0; h<min_rules_size-1;h++)
			{parent1.set(h, Array_temp2.get(h));
			//System.out.println("parent 1 : "+parent1.get(h).rule_text);
			} 
			
			for(int h= 0; h<min_rules_size-1;h++)
			{parent2.set(h, Array_temp.get(h));
			//System.out.println("parent 2 : "+parent2.get(h).rule_text);
			}
			
		return null;
	}
	public double fitness_1()
	{   
		double fitt = 0.0 ;
		
	    fitt = IntSolutionType.rules.size();     //(double)((int)rules.size())/((int)100);
		 System.out.println("fit1"+IntSolutionType.rules.size());
		System.out.println("fitness 1 = "+fitt);
	    
	   // fitt = 1 - fitt ;
		return fitt ;
		
	}
	public double fitness_2()
	{
		double fitnes2 = 0.0;
		int Nbr_Occ_Trace1=0;
		int Nbr_Occ_Trace2=0;
		int Nbr_Occ_Trace3=0;
		int Nbr_Occ_Trace4=0;
		int Nbr_Occ_Trace5=0;
		double []  Nbr_Occ_Trace =new double[16];
		double []  Nbr_Occ_Solution = new double[16]; 
		                                           //regularity grouping sequence simplicity density unity homogeneity economy balance uniformity cohesion nbelements clarity integrality
		String [][]  Interface_Metric = {{"aboutGnu","0.23","0.55","0.78","0.52","0.47","0.98","0.41","0.76","0.54","0.45","0.19","0.72","0.65","0.82"},
		                                 {"accounts","0.41","0.76","0.54","0.45","0.19","0.72","0.18","0.56","0.87","0.71","0.23","0.90","0.85","0.46"},
		                                 {"CreateAccount","0.65","0.82","0.50","0.51","0.72","0.44","0.03","0.54","0.72","0.49","0.32","0.55","0.71","0.15"},
		                                 {"settingsGnu","0.56","0.18","0.42","0.48","0.54","0.50","0.23","0.55","0.78","0.52","0.47","0.98","0.32","0.29"},
		                                 {"2048-205","0.18","0.56","0.87","0.71","0.23","0.90","0.63","0.70","0.89","0.04","0.21","0.26","0.93","0.64"},
		                                 {"aboutTisky","0.85","0.46","0.27","0.21","0.67","0.28","0.65","0.82","0.50","0.51","0.72","0.44","0.71","0.15"},
		                                 {"EditYourprofiletisky","0.93","0.64","0.35","0.67","0.38","0.14","0.63","0.70","0.89","0.04","0.21","0.26","0.71","0.15"},
		                                 {"HomeTisky","0.71","0.15","0.20","0.36","0.23","0.14","0.32","0.29","0.01","0.37","0.04","0.79","0.48","0.15"},
		                                 {"ArtistsShuffle","0.63","0.70","0.89","0.04","0.21","0.26","0.48","0.15","0.64","0.38","0.84","0.90","0.18","0.56"},
		                                 {"genresShuffle","0.48","0.15","0.64","0.38","0.84","0.90","0.18","0.56","0.87","0.71","0.23","0.90","0.03","0.54"},
		                                 {"LibraryShuffle","0.03","0.54","0.72","0.49","0.32","0.55","0.32","0.29","0.01","0.37","0.04","0.79","0.71","0.15"},
		                                 {"SettingsShuffle","0.32","0.29","0.01","0.37","0.04","0.79","0.03","0.54","0.72","0.49","0.32","0.55","0.71","0.15"},
		                                 {"SupportSuffle","0.32","0.29","0.01","0.37","0.04","0.79","0.03","0.54","0.72","0.49","0.32","0.55","0.71","0.15"},
		                                 {"Aboutgeo","0.32","0.29","0.01","0.37","0.04","0.79","0.03","0.54","0.72","0.49","0.32","0.55","0.71","0.15"},
		                                 {"CGeo","0.32","0.29","0.01","0.37","0.04","0.79","0.03","0.54","0.72","0.49","0.32","0.55","0.71","0.15"},
		                                 {"Geocoaching","0.32","0.29","0.01","0.37","0.04","0.79","0.03","0.54","0.72","0.49","0.32","0.55","0.71","0.15"},
		                                 {"homeCgeo","0.32","0.29","0.01","0.37","0.04","0.79","0.03","0.54","0.72","0.49","0.32","0.55","0.71","0.15"},
		                                 {"AboutFarebot","0.32","0.29","0.01","0.37","0.04","0.79","0.03","0.54","0.72","0.49","0.32","0.55","0.71","0.15"},
		                                 {"Supportedcards","0.32","0.29","0.01","0.37","0.04","0.79","0.03","0.54","0.72","0.49","0.32","0.55","0.71","0.15"},
		                                 {"AboutSimpleGallery","0.32","0.29","0.01","0.37","0.04","0.79","0.03","0.54","0.72","0.49","0.32","0.55","0.71","0.15"},
		                                 {"AllfoldersSimpleGallery","0.32","0.29","0.01","0.37","0.04","0.79","0.03","0.54","0.72","0.49","0.32","0.55","0.71","0.15"},
		                                 {"Gallery","0.32","0.29","0.01","0.37","0.04","0.79","0.03","0.54","0.72","0.49","0.32","0.55","0.71","0.15"},
		                                 {"settingsSimpleGallery","0.32","0.29","0.01","0.37","0.04","0.79","0.03","0.54","0.72","0.49","0.32","0.55","0.71","0.15"},
		                                 {"record","0.32","0.29","0.01","0.37","0.04","0.79","0.03","0.54","0.72","0.49","0.32","0.55","0.71","0.15"},
		                                 {"Telecine","0.32","0.29","0.01","0.37","0.04","0.79","0.03","0.54","0.72","0.49","0.32","0.55","0.71","0.15"},
		                                 {"ABoutLibreNews","0.32","0.29","0.01","0.37","0.04","0.79","0.03","0.54","0.72","0.49","0.32","0.55","0.71","0.15"},
		                                 {"LibreNews","0.32","0.29","0.01","0.37","0.04","0.79","0.03","0.54","0.72","0.49","0.32","0.55","0.71","0.15"},
		                                 {"appmanager","0.32","0.29","0.01","0.37","0.04","0.79","0.03","0.54","0.72","0.49","0.32","0.55","0.71","0.15"},
		                                 {"grid","0.32","0.29","0.01","0.37","0.04","0.79","0.03","0.54","0.72","0.49","0.32","0.55","0.71","0.15"},
		                                 {"list","0.32","0.29","0.01","0.37","0.04","0.79","0.03","0.54","0.72","0.49","0.32","0.55","0.71","0.15"},
		                                 {"settings","0.32","0.29","0.01","0.37","0.04","0.79","0.03","0.54","0.72","0.49","0.32","0.55","0.71","0.15"},
		                                 {"gettingstarted","0.32","0.29","0.01","0.37","0.04","0.79","0.03","0.54","0.72","0.49","0.32","0.55","0.71","0.15"},
		                                 {"orgzly","0.32","0.29","0.01","0.37","0.04","0.79","0.03","0.54","0.72","0.49","0.32","0.55","0.71","0.15"},
		                                 {"search","0.32","0.29","0.01","0.37","0.04","0.79","0.03","0.54","0.72","0.49","0.32","0.55","0.71","0.15"},
		                                 {"settingsOrgzly","0.32","0.29","0.01","0.37","0.04","0.79","0.03","0.54","0.72","0.49","0.32","0.55","0.71","0.15"},
		                                 {"todo","0.32","0.29","0.01","0.37","0.04","0.79","0.03","0.54","0.72","0.49","0.32","0.55","0.71","0.15"},
		                                 {"AboutNewpipe","0.32","0.29","0.01","0.37","0.04","0.79","0.03","0.54","0.72","0.49","0.32","0.55","0.71","0.15"},
		                                 {"history","0.32","0.29","0.01","0.37","0.04","0.79","0.03","0.54","0.72","0.49","0.32","0.55","0.71","0.15"},
		                                 {"neterror","0.32","0.29","0.01","0.37","0.04","0.79","0.03","0.54","0.72","0.49","0.32","0.55","0.71","0.15"},
		                                 {"play","0.32","0.29","0.01","0.37","0.04","0.79","0.03","0.54","0.72","0.49","0.32","0.55","0.71","0.15"},
		                                 {"search","0.32","0.29","0.01","0.37","0.04","0.79","0.03","0.54","0.72","0.49","0.32","0.55","0.71","0.15"},
		                                
		                                 {"welcome","0.32","0.29","0.01","0.37","0.04","0.79","0.03","0.54","0.72","0.49","0.32","0.55","0.71","0.15"}};       //new double[7][];
int Nbr_prob =0;
		 int k=1;
		 int t=1;
		 String nomFichier = "/Users/bessghaiernarjess/Documents/Ph.D_Thesis/main/tool/GP/perfect_rules.txt";
		 String val01 = null  ;
		 Workbook workbook = null;
		 
			/* R�cup�ration du classeur Excel (en lecture) */
			try {
				workbook = Workbook.getWorkbook(new File("Trace/evaluation_GP.xls"));
			} catch (BiffException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();}
		Sheet sheet =  workbook.getSheet(0);
		
		 for(int f= 0 ; f<= 64; f++)    // Nombre initiale 66
		  {
			 
			  jxl.Cell cell21 =  sheet.getCell(1, f);
			  String Pro1 =  cell21.getContents();
         	if( (Pro1.equalsIgnoreCase("ILW")))
         	      {  Nbr_Occ_Trace[0]++; }
         	if(  (Pro1.equalsIgnoreCase("ICM")))
   	              {  Nbr_Occ_Trace[1]++; }
         	if( (Pro1.equalsIgnoreCase("IM")))
   	              {   Nbr_Occ_Trace[2]++; }
         	if((Pro1.equalsIgnoreCase("OM")))
   	              {   Nbr_Occ_Trace[3]++; }
         
         	
        
  }
		
		
			  /////rule1
		  for (int i=0; i<IntSolutionType.rules.size();i++){
			  
			
			  String Problem=IntSolutionType.rules.get(i).trg ;
			  String operateur = IntSolutionType.rules.get(i).src0 ; 
			  String Metric=IntSolutionType.rules.get(i).src ;
		
			  String Val_Metric = IntSolutionType.rules.get(i).src1;
			  double Metric1 = 0.0 ;
			  double Metric2 = 0.0 ;
			  //System.out.println("///////////////////"+Val_Metric);
			  k =1;
			  boolean bol = false;  
			  for(int j=0;j<1;j++)
				  
			  {
			  
				  while (k<66 && bol == false ){
					 
					  jxl.Cell cell21 =  sheet.getCell(1, k);
					  String Pro1 =  cell21.getContents();
					  
					
	                	jxl.Cell Valeurs =  sheet.getCell(j, k);
	                	String Val =  Valeurs.getContents();
	                	
	                	if((Val_Metric.equalsIgnoreCase(Val) &&(Problem.equalsIgnoreCase(Pro1))))
	                	{   if (  
               	    		 (Metric=="Regularity"|| Metric=="Layout uniformity" || Metric=="Sequence"|| Metric=="Homogeneity" || Metric=="Simplicity"&& (Problem=="ILW")) ||
               	    		 (Metric=="Cohesion" || Metric=="Layout uniformity" || Metric=="Sequence"|| Metric=="Grouping"&& (Problem=="ICM"))||
               	    		 (Metric=="Balance" || Metric=="Layout uniformity" && (Problem=="IM")) ||
               	    		 (Metric=="Nbelements"|| Metric=="Density"|| Metric=="Economy"|| Metric=="Integrality"&&(Problem=="OM"))
               	    		)
	                		      {  jxl.Cell cell23 =  sheet.getCell(0, k);
	        					     String Interface =  cell23.getContents();
	        					             if (Interface.equalsIgnoreCase("aboutGnu"))
	        					               { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[0][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[0][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[0][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[0][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[0][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[0][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[0][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[0][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[0][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[0][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[0][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[0][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[0][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[0][14];}
	        					            	 
		        					             
	        					            else if (Interface.equalsIgnoreCase("accounts"))
				        					    { 
	        					            	System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[1][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[1][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[1][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[1][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[1][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[1][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[1][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[1][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[1][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[1][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[1][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[1][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[1][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[1][14];}
	        					            	 
		        					                
				        					     }
				        					            	 
				        					
	        					             else if (Interface.equalsIgnoreCase("CreateAccount"))
				        					    { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[2][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[2][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[2][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[2][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[2][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[2][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[2][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[2][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[2][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[2][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[2][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[2][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[2][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[2][14];}
	        					            	 
		        					                
				        					     }

	        					             else if (Interface.equalsIgnoreCase("settingsGnu"))
				        					    { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[3][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[3][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[3][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[3][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[3][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[3][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[3][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[3][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[3][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[3][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[3][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[3][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[3][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[3][14];}
	        					            	 
		        					                
				        					     }
				        					            	 
				        					            	 
	        					             else if (Interface.equalsIgnoreCase("2048-205"))
					        				   { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[4][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[4][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[4][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[4][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[4][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[4][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[4][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[4][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[4][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[4][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[4][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[4][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[4][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[4][14];}
	        					            	 
		        					               
					        				   }
					        					            	
	        					             else if (Interface.equalsIgnoreCase("aboutTisky"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[5][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[5][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[5][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[5][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[5][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[5][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[5][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[5][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[5][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[5][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[5][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[5][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[5][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[5][14];}
	        					            	 
                                                }
	        					             else if (Interface.equalsIgnoreCase("EditYourprofiletisky"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[6][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[6][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[6][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[6][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[6][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[6][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[6][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[6][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[6][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[6][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[6][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[6][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[6][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[6][14];}
	        					            	 
                                               }
	        					             else if (Interface.equalsIgnoreCase("HomeTisky"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[7][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[7][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[7][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[7][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[7][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[7][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[7][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[7][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[7][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[7][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[7][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[7][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[7][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[7][14];}
	        					            	 
                                               }
	        					             else if (Interface.equalsIgnoreCase("ArtistsShuffle"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[8][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[8][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[8][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[8][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[8][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[8][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[8][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[8][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[8][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[8][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[8][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[8][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[8][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[8][14];}
	        					            	 
                                               }
	        					             else if (Interface.equalsIgnoreCase("genresShuffle"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[9][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[9][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[9][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[9][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[9][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[9][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[9][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[9][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[9][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[9][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[9][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[9][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[9][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[9][14];}
	        					            	 
                                               }
	        					             else if (Interface.equalsIgnoreCase("LibraryShuffle"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[10][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[10][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[10][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[10][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[10][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[10][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[10][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[10][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[10][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[10][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[10][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[10][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[10][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[10][14];}
	        					            	 
                                               }
	        					             else if (Interface.equalsIgnoreCase("SettingsShuffle"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[11][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[11][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[11][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[11][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[11][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[11][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[11][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[11][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[11][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[11][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[11][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[11][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[11][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[11][14];}
	        					            	 
                                               }
	        					             
		        					              
	        					             else if (Interface.equalsIgnoreCase("SupportSuffle"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[12][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[12][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[12][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[12][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[12][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[12][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[12][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[12][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[12][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[12][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[12][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[12][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[12][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[12][14];}
	        					            	 
                                              }
		        					              
	        					             else if (Interface.equalsIgnoreCase("Aboutgeo"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[13][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[13][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[13][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[13][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[13][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[13][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[13][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[13][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[13][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[13][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[13][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[13][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[13][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[13][14];}
	        					            	 
                                              }
		        					              
		        					              
	        					             else if (Interface.equalsIgnoreCase("CGeo"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[14][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[14][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[14][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[14][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[14][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[14][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[14][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[14][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[14][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[14][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[14][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[14][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[14][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[14][14];}
	        					            	 
                                              }
		        					              
		        					              
	        					             else if (Interface.equalsIgnoreCase("Geocoaching"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[15][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[15][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[15][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[15][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[15][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[15][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[15][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[15][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[15][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[15][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[15][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[15][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[15][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[15][14];}
	        					            	 
                                              }
		        					              
		        					              
	        					             else if (Interface.equalsIgnoreCase("homeCgeo"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[16][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[16][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[16][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[16][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[16][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[16][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[16][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[16][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[16][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[16][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[16][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[16][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[16][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[16][14];}
	        					            	 
                                              }
		        					              
		        					              
	        					             else if (Interface.equalsIgnoreCase("AboutFarebot"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[17][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[17][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[17][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[17][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[17][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[17][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[17][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[17][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[17][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[17][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[17][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[17][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[17][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[17][14];}
	        					            	 
                                              }
		        					              
		        					              
	        					             else if (Interface.equalsIgnoreCase("Supportedcards"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[18][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[18][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[18][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[18][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[18][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[18][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[18][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[18][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[18][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[18][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[18][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[18][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[18][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[18][14];}
	        					            	 
                                              }
		        					              
		        					              
	        					             else if (Interface.equalsIgnoreCase("AboutSimpleGallery"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[19][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[19][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[19][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[19][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[19][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[19][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[19][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[19][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[19][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[19][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[19][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[19][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[19][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[19][14];}
	        					            	 
                                              }
		        					              
		        					              
	        					             else if (Interface.equalsIgnoreCase("AllfoldersSimpleGallery"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[20][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[20][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[20][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[20][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[20][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[20][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[20][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[20][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[20][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[20][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[20][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[20][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[20][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[20][14];}
	        					            	 
                                              }
		        					              
		        					              
	        					             else if (Interface.equalsIgnoreCase("Gallery"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[21][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[21][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[21][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[21][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[21][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[21][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[21][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[21][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[21][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[21][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[21][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[21][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[21][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[21][14];}
	        					            	 
                                              }
		        					              
	        					             else if (Interface.equalsIgnoreCase("settingsSimpleGallery"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[22][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[22][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[22][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[22][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[22][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[22][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[22][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[22][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[22][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[22][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[22][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[22][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[22][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[22][14];}
	        					            	 
                                              }
		        					              
	        					             else if (Interface.equalsIgnoreCase("record"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[23][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[23][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[23][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[23][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[23][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[23][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[23][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[23][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[23][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[23][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[23][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[23][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[23][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[23][14];}
	        					            	 
                                              }
		        					              
	        					             else if (Interface.equalsIgnoreCase("Telecine"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[24][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[24][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[24][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[24][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[24][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[24][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[24][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[24][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[24][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[24][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[24][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[24][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[24][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[24][14];}
	        					            	 
                                              }
		        					              
	        					             else if (Interface.equalsIgnoreCase("ABoutLibreNews"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[25][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[25][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[25][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[25][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[25][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[25][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[25][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[25][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[25][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[25][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[25][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[25][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[25][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[25][14];}
	        					            	 
                                              }
		        					              
	        					             else if (Interface.equalsIgnoreCase("LibreNews"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[26][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[26][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[26][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[26][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[26][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[26][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[26][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[26][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[26][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[26][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[26][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[26][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[26][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[26][14];}
	        					            	 
                                             }
	        					             else if (Interface.equalsIgnoreCase("appmanager"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[27][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[27][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[27][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[27][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[27][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[27][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[27][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[27][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[27][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[27][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[27][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[27][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[27][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[27][14];}
	        					            	 
                                             }
	        					             else if (Interface.equalsIgnoreCase("grid"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[28][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[28][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[28][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[28][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[28][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[28][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[28][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[28][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[28][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[28][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[28][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[28][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[28][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[28][14];}
	        					            	 
                                             }
	        					             else if (Interface.equalsIgnoreCase("list"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[29][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[29][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[29][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[29][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[29][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[29][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[29][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[29][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[29][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[29][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[29][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[29][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[29][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[29][14];}
	        					            	 
                                             }
	        					             else if (Interface.equalsIgnoreCase("settings"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[30][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[30][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[30][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[30][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[30][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[30][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[30][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[30][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[30][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[30][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[30][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[30][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[30][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[30][14];}
	        					            	 
                                             }
	        					             else if (Interface.equalsIgnoreCase("gettingstarted"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[31][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[31][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[31][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[31][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[31][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[31][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[31][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[31][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[31][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[31][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[31][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[31][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[31][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[31][14];}
	        					            	 
                                             }
	        					             else if (Interface.equalsIgnoreCase("orgzly"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[32][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[32][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[32][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[32][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[32][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[32][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[32][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[32][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[32][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[32][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[32][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[32][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[32][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[32][14];}
	        					            	 
                                             }
	        					             else if (Interface.equalsIgnoreCase("search"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[33][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[33][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[33][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[33][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[33][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[33][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[33][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[33][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[33][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[33][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[33][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[33][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[33][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[33][14];}
	        					            	 
                                             }
	        					             else if (Interface.equalsIgnoreCase("settingsOrgzly"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[34][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[34][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[34][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[34][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[34][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[34][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[34][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[34][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[34][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[34][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[34][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[34][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[34][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[34][14];}
	        					            	 
                                             }
	        					             else if (Interface.equalsIgnoreCase("todo"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[35][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[35][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[35][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[35][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[35][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[35][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[35][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[35][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[35][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[35][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[35][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[35][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[35][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[35][14];}
	        					            	 
                                             }
	        					             else if (Interface.equalsIgnoreCase("AboutNewpipe"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[36][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[36][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[36][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[36][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[36][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[36][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[36][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[36][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[36][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[36][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[36][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[36][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[36][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[36][14];}
	        					            	 
                                             }
	        					             else if (Interface.equalsIgnoreCase("history"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[37][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[37][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[37][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[37][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[37][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[37][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[37][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[37][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[37][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[37][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[37][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[37][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[37][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[37][14];}
	        					            	 
                                             }
	        					             else if (Interface.equalsIgnoreCase("neterror"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[38][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[38][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[38][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[38][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[38][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[38][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[38][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[38][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[38][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[38][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[38][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[38][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[38][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[38][14];}
	        					            	 
                                             }
	        					             else if (Interface.equalsIgnoreCase("play"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[39][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[39][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[39][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[39][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[39][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[39][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[39][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[39][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[39][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[39][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[39][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[39][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[39][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[39][14];}
	        					            	 
                                             }
	        					             else if (Interface.equalsIgnoreCase("search"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[40][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[40][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[40][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[40][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[40][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[40][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[40][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[40][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[40][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[40][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[40][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[40][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[40][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[40][14];}
	        					            	 
                                             }
	        					            
	        					             else if (Interface.equalsIgnoreCase("welcome"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[42][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[42][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[42][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[42][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[42][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[42][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[42][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[42][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[42][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[42][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[42][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[42][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[42][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[42][14];}
	        					            	 
                                             }
		        					              
		        					              
		        					              
		        					              
		        					              
		        					              
	        					            
	        					             else 
	        					                     {  val01 = "0.0";  }
	        					                     
	        					           Metric1 = Double.parseDouble(Val_Metric);
	        					           Metric2 = Double.parseDouble(val01);
	        					           
	        					              

	        					           if ((Problem.equalsIgnoreCase("ILW")||
	        					            		Problem.equalsIgnoreCase("ICM")||
	        					            		Problem.equalsIgnoreCase("OM")||
	        					            		Problem.equalsIgnoreCase("IM"))
	        					            		  && (operateur.equalsIgnoreCase(">=")) && (Metric1 >= Metric2)) {
	        					        	   System.out.println("--------------------------Thats right--------------------------");
		        					        	   System.out.println("(((())))))))"+val01+"    "+Metric+"        "+Interface);
		        					        	     Nbr_prob++  ;
		        					        	     //perfect_rule.add(Perfect);
			                			             
		             			                          if( (Problem.equalsIgnoreCase("ILW")))
		                         	                                {  System.out.println("--------------------------");
		             			                        	             Nbr_Occ_Solution[0] =  Nbr_Occ_Solution[0]+1; }
		                         	                      if(  (Problem.equalsIgnoreCase("ICM")))
		                   	                                        {  Nbr_Occ_Solution[1]= Nbr_Occ_Solution[1]+1 ; }
		                         	                      if( (Problem.equalsIgnoreCase("IM")))
		                   	                                        {   Nbr_Occ_Solution[2] =  Nbr_Occ_Solution[2] + 1 ;}
		                         	                      if((Problem.equalsIgnoreCase("OM")))
		                   	                                          {  Nbr_Occ_Solution[3] =  Nbr_Occ_Solution[3]+1;}
		                         	                     
		                         	                      
		        					           }
	        					           
	        					           
	        					           Metric1 = Double.parseDouble(Val_Metric);
	        					           Metric2 = Double.parseDouble(val01);
	        					           
	        					           if (
	        					        		   (Problem.equalsIgnoreCase("ILW")||
	        					            		Problem.equalsIgnoreCase("ICM")||
	        					            		Problem.equalsIgnoreCase("OM")||
	        					            		Problem.equalsIgnoreCase("IM"))
	        					            		  && (operateur.equalsIgnoreCase("<=")) && (Metric1 <= Metric2)) {
	        					        	   System.out.println("--------------------------Thats right--------------------------");
		        					        	   System.out.println("(((())))))))"+val01+"    "+Metric+"        "+Interface);
		        					        	     Nbr_prob++  ;
		        					        	     //perfect_rule.add(Perfect);
			                			             
		             			                          if( (Problem.equalsIgnoreCase("ILW")))
		                         	                                {  System.out.println("--------------------------");
		             			                        	             Nbr_Occ_Solution[0] =  Nbr_Occ_Solution[0]+1; }
		                         	                      if(  (Problem.equalsIgnoreCase("ICM")))
		                   	                                        {  Nbr_Occ_Solution[1]= Nbr_Occ_Solution[1]+1 ; }
		                         	                      if( (Problem.equalsIgnoreCase("IM")))
		                   	                                        {   Nbr_Occ_Solution[2] =  Nbr_Occ_Solution[2] + 1 ;}
		                         	                      if((Problem.equalsIgnoreCase("OM")))
		                   	                                          {  Nbr_Occ_Solution[3] =  Nbr_Occ_Solution[3]+1;}
		                         	                      
		                         	                      
		        					           }
	        					           
	        					           
	        					         
	        					       
	        					      
	                			       bol = true;
	                			        
		           	                   

	                	}
	                	}
		            k++; 
		            Nbr_Occ_Trace1++;
	                	}
				  // k =1;
				  
	             }}
			  
	}	 
		  
		  
		  
		  /////rule2 testing
		  for (int i=0; i<IntSolutionType.rules2.size();i++){
			  
			
			  String Problem=IntSolutionType.rules2.get(i).trg ;
			
			  String Metric=IntSolutionType.rules2.get(i).src ;
			  String operateur = IntSolutionType.rules2.get(i).src0 ; 
			  String Val_Metric = IntSolutionType.rules2.get(i).src1;
			 
			  
			  double Metric1 = 0.0 ;
			  double Metric2 = 0.0 ;
			  //System.out.println("///////////////////"+Val_Metric);
			  k =1;
			  boolean bol = false;
			
			         
			  for(int j=0;j<1;j++)
				  
			  {
			  
				  while (k<66 && bol == false ){
					 
					  jxl.Cell cell21 =  sheet.getCell(1, k);
					  String Pro1 =  cell21.getContents();
					  
					
	                	jxl.Cell Valeurs =  sheet.getCell(j, k);
	                	String Val =  Valeurs.getContents();
	                	
	                	if((Val_Metric.equalsIgnoreCase(Val) &&(Problem.equalsIgnoreCase(Pro1))))
	                	{   if (  
               	    		 (Metric=="Regularity"|| Metric=="Layout uniformity" || Metric=="Sequence"|| Metric=="Homogeneity" || Metric=="Simplicity"&& (Problem=="ILW")) ||
               	    		 (Metric=="Cohesion" || Metric=="Layout uniformity" || Metric=="Sequence"|| Metric=="Grouping"&& (Problem=="ICM"))||
               	    		 (Metric=="Balance" || Metric=="Layout uniformity" && (Problem=="IM")) ||
               	    		 (Metric=="Nbelements"|| Metric=="Density"|| Metric=="Economy"|| Metric=="Integrality"&&(Problem=="OM"))
               	    		)
	                		      {  jxl.Cell cell23 =  sheet.getCell(0, k);
	        					     String Interface =  cell23.getContents();
	        					             if (Interface.equalsIgnoreCase("aboutGnu"))
	        					               { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[0][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[0][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[0][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[0][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[0][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[0][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[0][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[0][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[0][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[0][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[0][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[0][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[0][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[0][14];}
	        					            	 
	        					       
	        					            else if (Interface.equalsIgnoreCase("accounts"))
				        					    { 
	        					            	System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[1][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[1][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[1][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[1][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[1][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[1][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[1][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[1][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[1][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[1][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[1][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[1][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[1][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[1][14];}
	        					            	 
		        					                
				        					     }
				        					            	 
				        					
	        					             else if (Interface.equalsIgnoreCase("CreateAccount"))
				        					    { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[2][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[2][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[2][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[2][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[2][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[2][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[2][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[2][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[2][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[2][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[2][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[2][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[2][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[2][14];}
	        					            	 
		        					                
				        					     }

	        					             else if (Interface.equalsIgnoreCase("settingsGnu"))
				        					    { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[3][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[3][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[3][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[3][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[3][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[3][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[3][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[3][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[3][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[3][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[3][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[3][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[3][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[3][14];}
	        					            	 
		        					                
				        					     }
				        					            	 
				        					            	 
	        					             else if (Interface.equalsIgnoreCase("2048-205"))
					        				   { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[4][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[4][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[4][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[4][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[4][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[4][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[4][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[4][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[4][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[4][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[4][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[4][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[4][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[4][14];}
	        					            	 
		        					               
					        				   }
					        					            	
	        					             else if (Interface.equalsIgnoreCase("aboutTisky"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[5][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[5][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[5][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[5][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[5][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[5][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[5][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[5][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[5][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[5][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[5][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[5][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[5][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[5][14];}
	        					            	 
                                                }
	        					             else if (Interface.equalsIgnoreCase("EditYourprofiletisky"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[6][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[6][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[6][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[6][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[6][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[6][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[6][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[6][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[6][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[6][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[6][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[6][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[6][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[6][14];}
	        					            	 
                                               }
	        					             else if (Interface.equalsIgnoreCase("HomeTisky"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[7][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[7][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[7][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[7][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[7][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[7][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[7][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[7][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[7][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[7][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[7][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[7][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[7][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[7][14];}
	        					            	 
                                               }
	        					             else if (Interface.equalsIgnoreCase("ArtistsShuffle"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[8][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[8][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[8][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[8][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[8][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[8][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[8][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[8][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[8][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[8][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[8][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[8][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[8][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[8][14];}
	        					            	 
                                               }
	        					             else if (Interface.equalsIgnoreCase("genresShuffle"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[9][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[9][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[9][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[9][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[9][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[9][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[9][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[9][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[9][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[9][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[9][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[9][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[9][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[9][14];}
	        					            	 
                                               }
	        					             else if (Interface.equalsIgnoreCase("LibraryShuffle"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[10][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[10][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[10][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[10][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[10][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[10][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[10][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[10][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[10][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[10][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[10][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[10][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[10][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[10][14];}
	        					            	 
                                               }
	        					             else if (Interface.equalsIgnoreCase("SettingsShuffle"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[11][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[11][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[11][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[11][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[11][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[11][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[11][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[11][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[11][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[11][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[11][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[11][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[11][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[11][14];}
	        					            	 
                                               }
	        					             
		        					              
	        					             else if (Interface.equalsIgnoreCase("SupportSuffle"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[12][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[12][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[12][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[12][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[12][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[12][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[12][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[12][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[12][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[12][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[12][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[12][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[12][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[12][14];}
	        					            	 
                                              }
		        					              
	        					             else if (Interface.equalsIgnoreCase("Aboutgeo"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[13][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[13][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[13][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[13][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[13][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[13][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[13][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[13][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[13][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[13][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[13][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[13][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[13][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[13][14];}
	        					            	 
                                              }
		        					              
		        					              
	        					             else if (Interface.equalsIgnoreCase("CGeo"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[14][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[14][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[14][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[14][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[14][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[14][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[14][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[14][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[14][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[14][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[14][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[14][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[14][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[14][14];}
	        					            	 
                                              }
		        					              
		        					              
	        					             else if (Interface.equalsIgnoreCase("Geocoaching"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[15][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[15][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[15][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[15][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[15][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[15][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[15][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[15][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[15][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[15][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[15][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[15][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[15][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[15][14];}
	        					            	 
                                              }
		        					              
		        					              
	        					             else if (Interface.equalsIgnoreCase("homeCgeo"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[16][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[16][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[16][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[16][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[16][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[16][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[16][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[16][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[16][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[16][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[16][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[16][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[16][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[16][14];}
	        					            	 
                                              }
		        					              
		        					              
	        					             else if (Interface.equalsIgnoreCase("AboutFarebot"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[17][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[17][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[17][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[17][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[17][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[17][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[17][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[17][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[17][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[17][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[17][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[17][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[17][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[17][14];}
	        					            	 
                                              }
		        					              
		        					              
	        					             else if (Interface.equalsIgnoreCase("Supportedcards"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[18][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[18][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[18][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[18][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[18][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[18][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[18][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[18][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[18][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[18][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[18][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[18][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[18][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[18][14];}
	        					            	 
                                              }
		        					              
		        					              
	        					             else if (Interface.equalsIgnoreCase("AboutSimpleGallery"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[19][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[19][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[19][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[19][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[19][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[19][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[19][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[19][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[19][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[19][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[19][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[19][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[19][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[19][14];}
	        					            	 
                                              }
		        					              
		        					              
	        					             else if (Interface.equalsIgnoreCase("AllfoldersSimpleGallery"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[20][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[20][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[20][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[20][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[20][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[20][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[20][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[20][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[20][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[20][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[20][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[20][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[20][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[20][14];}
	        					            	 
                                              }
		        					              
		        					              
	        					             else if (Interface.equalsIgnoreCase("Gallery"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[21][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[21][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[21][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[21][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[21][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[21][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[21][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[21][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[21][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[21][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[21][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[21][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[21][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[21][14];}
	        					            	 
                                              }
		        					              
	        					             else if (Interface.equalsIgnoreCase("settingsSimpleGallery"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[22][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[22][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[22][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[22][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[22][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[22][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[22][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[22][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[22][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[22][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[22][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[22][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[22][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[22][14];}
	        					            	 
                                              }
		        					              
	        					             else if (Interface.equalsIgnoreCase("record"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[23][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[23][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[23][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[23][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[23][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[23][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[23][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[23][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[23][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[23][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[23][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[23][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[23][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[23][14];}
	        					            	 
                                              }
		        					              
	        					             else if (Interface.equalsIgnoreCase("Telecine"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[24][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[24][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[24][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[24][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[24][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[24][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[24][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[24][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[24][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[24][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[24][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[24][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[24][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[24][14];}
	        					            	 
                                              }
		        					              
	        					             else if (Interface.equalsIgnoreCase("ABoutLibreNews"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[25][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[25][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[25][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[25][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[25][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[25][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[25][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[25][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[25][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[25][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[25][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[25][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[25][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[25][14];}
	        					            	 
                                              }
		        					              
	        					             else if (Interface.equalsIgnoreCase("LibreNews"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[26][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[26][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[26][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[26][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[26][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[26][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[26][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[26][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[26][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[26][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[26][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[26][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[26][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[26][14];}
	        					            	 
                                             }
	        					             else if (Interface.equalsIgnoreCase("appmanager"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[27][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[27][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[27][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[27][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[27][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[27][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[27][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[27][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[27][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[27][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[27][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[27][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[27][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[27][14];}
	        					            	 
                                             }
	        					             else if (Interface.equalsIgnoreCase("grid"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[28][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[28][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[28][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[28][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[28][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[28][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[28][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[28][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[28][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[28][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[28][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[28][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[28][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[28][14];}
	        					            	 
                                             }
	        					             else if (Interface.equalsIgnoreCase("list"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[29][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[29][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[29][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[29][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[29][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[29][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[29][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[29][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[29][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[29][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[29][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[29][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[29][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[29][14];}
	        					            	 
                                             }
	        					             else if (Interface.equalsIgnoreCase("settings"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[30][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[30][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[30][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[30][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[30][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[30][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[30][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[30][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[30][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[30][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[30][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[30][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[30][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[30][14];}
	        					            	 
                                             }
	        					             else if (Interface.equalsIgnoreCase("gettingstarted"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[31][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[31][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[31][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[31][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[31][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[31][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[31][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[31][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[31][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[31][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[31][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[31][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[31][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[31][14];}
	        					            	 
                                             }
	        					             else if (Interface.equalsIgnoreCase("orgzly"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[32][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[32][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[32][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[32][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[32][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[32][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[32][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[32][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[32][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[32][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[32][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[32][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[32][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[32][14];}
	        					            	 
                                             }
	        					             else if (Interface.equalsIgnoreCase("search"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[33][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[33][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[33][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[33][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[33][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[33][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[33][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[33][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[33][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[33][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[33][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[33][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[33][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[33][14];}
	        					            	 
                                             }
	        					             else if (Interface.equalsIgnoreCase("settingsOrgzly"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[34][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[34][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[34][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[34][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[34][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[34][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[34][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[34][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[34][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[34][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[34][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[34][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[34][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[34][14];}
	        					            	 
                                             }
	        					             else if (Interface.equalsIgnoreCase("todo"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[35][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[35][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[35][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[35][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[35][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[35][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[35][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[35][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[35][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[35][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[35][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[35][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[35][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[35][14];}
	        					            	 
                                             }
	        					             else if (Interface.equalsIgnoreCase("AboutNewpipe"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[36][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[36][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[36][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[36][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[36][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[36][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[36][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[36][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[36][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[36][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[36][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[36][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[36][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[36][14];}
	        					            	 
                                             }
	        					             else if (Interface.equalsIgnoreCase("history"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[37][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[37][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[37][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[37][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[37][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[37][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[37][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[37][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[37][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[37][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[37][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[37][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[37][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[37][14];}
	        					            	 
                                             }
	        					             else if (Interface.equalsIgnoreCase("neterror"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[38][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[38][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[38][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[38][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[38][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[38][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[38][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[38][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[38][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[38][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[38][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[38][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[38][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[38][14];}
	        					            	 
                                             }
	        					             else if (Interface.equalsIgnoreCase("play"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[39][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[39][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[39][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[39][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[39][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[39][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[39][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[39][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[39][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[39][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[39][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[39][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[39][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[39][14];}
	        					            	 
                                             }
	        					             else if (Interface.equalsIgnoreCase("search"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[40][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[40][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[40][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[40][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[40][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[40][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[40][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[40][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[40][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[40][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[40][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[40][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[40][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[40][14];}
	        					            	 
                                             }
	        					            
	        					             else if (Interface.equalsIgnoreCase("welcome"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[42][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[42][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[42][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[42][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[42][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[42][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[42][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[42][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[42][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[42][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[42][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[42][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[42][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[42][14];}
	        					            	 
                                             }
		        					              
		        					              
		        					              
		        					              
		        					              
		        					              
	        					            
	        					             else 
	        					                     {  val01 = "0.0";  }
	        					                     
	        					           Metric1 = Double.parseDouble(Val_Metric);
	        					           Metric2 = Double.parseDouble(val01);
	        					           
	        					              

	        					           if ((Problem.equalsIgnoreCase("ILW")||
	        					            		Problem.equalsIgnoreCase("ICM")||
	        					            		Problem.equalsIgnoreCase("OM")||
	        					            		Problem.equalsIgnoreCase("IM"))
	        					            		  && (operateur.equalsIgnoreCase(">=")) && (Metric1 >= Metric2)) {
	        					        	   System.out.println("--------------------------Thats right--------------------------");
		        					        	   System.out.println("(((())))))))"+val01+"    "+Metric+"        "+Interface);
		        					        	     Nbr_prob++  ;
		        					        	     //perfect_rule.add(Perfect);
			                			             
		             			                          if( (Problem.equalsIgnoreCase("ILW")))
		                         	                                {  System.out.println("--------------------------");
		             			                        	             Nbr_Occ_Solution[0] =  Nbr_Occ_Solution[0]+1; }
		                         	                      if(  (Problem.equalsIgnoreCase("ICM")))
		                   	                                        {  Nbr_Occ_Solution[1]= Nbr_Occ_Solution[1]+1 ; }
		                         	                      if( (Problem.equalsIgnoreCase("IM")))
		                   	                                        {   Nbr_Occ_Solution[2] =  Nbr_Occ_Solution[2] + 1 ;}
		                         	                      if((Problem.equalsIgnoreCase("OM")))
		                   	                                          {  Nbr_Occ_Solution[3] =  Nbr_Occ_Solution[3]+1;}
		                         	                     
		                         	                      
		        					           }
	        					           
	        					           
	        					           Metric1 = Double.parseDouble(Val_Metric);
	        					           Metric2 = Double.parseDouble(val01);
	        					           
	        					           if (
	        					        		   (Problem.equalsIgnoreCase("ILW")||
	        					            		Problem.equalsIgnoreCase("ICM")||
	        					            		Problem.equalsIgnoreCase("OM")||
	        					            		Problem.equalsIgnoreCase("IM"))
	        					            		  && (operateur.equalsIgnoreCase("<=")) && (Metric1 <= Metric2)) {
	        					        	   System.out.println("--------------------------Thats right--------------------------");
		        					        	   System.out.println("(((())))))))"+val01+"    "+Metric+"        "+Interface);
		        					        	     Nbr_prob++  ;
		        					        	     //perfect_rule.add(Perfect);
			                			             
		             			                          if( (Problem.equalsIgnoreCase("ILW")))
		                         	                                {  System.out.println("--------------------------");
		             			                        	             Nbr_Occ_Solution[0] =  Nbr_Occ_Solution[0]+1; }
		                         	                      if(  (Problem.equalsIgnoreCase("ICM")))
		                   	                                        {  Nbr_Occ_Solution[1]= Nbr_Occ_Solution[1]+1 ; }
		                         	                      if( (Problem.equalsIgnoreCase("IM")))
		                   	                                        {   Nbr_Occ_Solution[2] =  Nbr_Occ_Solution[2] + 1 ;}
		                         	                      if((Problem.equalsIgnoreCase("OM")))
		                   	                                          {  Nbr_Occ_Solution[3] =  Nbr_Occ_Solution[3]+1;}
		                         	                      
		                         	                      
		        					           }
	        					           
	        					           
	        					         
	        					       
	        					      
	                			       bol = true;
	                			        
		           	                   

	                	}
	                	}
		            k++; 
		            Nbr_Occ_Trace2++;
	                	}
				  // k =1;
				  
	             }}
			  
	}	 
		  
		   
		  
		  /////rule3 testing
		  for (int i=0; i<IntSolutionType.rules3.size();i++){
			  
			
			  String Problem=IntSolutionType.rules3.get(i).trg ;
			
			  String Metric=IntSolutionType.rules3.get(i).src ;
			  String operateur = IntSolutionType.rules3.get(i).src0 ; 
			  String Val_Metric = IntSolutionType.rules3.get(i).src1;
			 
			  
			  double Metric1 = 0.0 ;
			  double Metric2 = 0.0 ;
			  //System.out.println("///////////////////"+Val_Metric);
			  k =1;
			  boolean bol = false;
			
			         
			  for(int j=0;j<1;j++)
				  
			  {
			  
				  while (k<66 && bol == false ){
					 
					  jxl.Cell cell21 =  sheet.getCell(1, k);
					  String Pro1 =  cell21.getContents();
					  
					
	                	jxl.Cell Valeurs =  sheet.getCell(j, k);
	                	String Val =  Valeurs.getContents();
	                	
	                	if((Val_Metric.equalsIgnoreCase(Val) &&(Problem.equalsIgnoreCase(Pro1))))
	                	{   if (  
               	    		 (Metric=="Regularity"|| Metric=="Layout uniformity" || Metric=="Sequence"|| Metric=="Homogeneity" || Metric=="Simplicity"&& (Problem=="ILW")) ||
               	    		 (Metric=="Cohesion" || Metric=="Layout uniformity" || Metric=="Sequence"|| Metric=="Grouping"&& (Problem=="ICM"))||
               	    		 (Metric=="Balance" || Metric=="Layout uniformity" && (Problem=="IM")) ||
               	    		 (Metric=="Nbelements"|| Metric=="Density"|| Metric=="Economy"|| Metric=="Integrality"&&(Problem=="OM"))
               	    		)
	                		      {  jxl.Cell cell23 =  sheet.getCell(0, k);
	        					     String Interface =  cell23.getContents();
	        					             if (Interface.equalsIgnoreCase("aboutGnu"))
	        					               { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[0][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[0][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[0][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[0][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[0][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[0][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[0][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[0][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[0][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[0][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[0][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[0][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[0][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[0][14];}
	        					            	 
	        					       
	        					            else if (Interface.equalsIgnoreCase("accounts"))
				        					    { 
	        					            	System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[1][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[1][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[1][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[1][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[1][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[1][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[1][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[1][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[1][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[1][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[1][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[1][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[1][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[1][14];}
	        					            	 
		        					                
				        					     }
				        					            	 
				        					
	        					             else if (Interface.equalsIgnoreCase("CreateAccount"))
				        					    { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[2][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[2][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[2][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[2][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[2][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[2][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[2][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[2][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[2][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[2][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[2][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[2][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[2][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[2][14];}
	        					            	 
		        					                
				        					     }

	        					             else if (Interface.equalsIgnoreCase("settingsGnu"))
				        					    { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[3][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[3][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[3][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[3][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[3][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[3][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[3][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[3][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[3][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[3][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[3][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[3][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[3][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[3][14];}
	        					            	 
		        					                
				        					     }
				        					            	 
				        					            	 
	        					             else if (Interface.equalsIgnoreCase("2048-205"))
					        				   { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[4][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[4][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[4][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[4][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[4][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[4][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[4][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[4][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[4][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[4][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[4][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[4][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[4][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[4][14];}
	        					            	 
		        					               
					        				   }
					        					            	
	        					             else if (Interface.equalsIgnoreCase("aboutTisky"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[5][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[5][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[5][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[5][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[5][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[5][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[5][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[5][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[5][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[5][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[5][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[5][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[5][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[5][14];}
	        					            	 
                                                }
	        					             else if (Interface.equalsIgnoreCase("EditYourprofiletisky"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[6][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[6][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[6][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[6][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[6][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[6][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[6][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[6][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[6][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[6][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[6][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[6][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[6][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[6][14];}
	        					            	 
                                               }
	        					             else if (Interface.equalsIgnoreCase("HomeTisky"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[7][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[7][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[7][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[7][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[7][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[7][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[7][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[7][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[7][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[7][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[7][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[7][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[7][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[7][14];}
	        					            	 
                                               }
	        					             else if (Interface.equalsIgnoreCase("ArtistsShuffle"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[8][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[8][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[8][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[8][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[8][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[8][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[8][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[8][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[8][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[8][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[8][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[8][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[8][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[8][14];}
	        					            	 
                                               }
	        					             else if (Interface.equalsIgnoreCase("genresShuffle"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[9][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[9][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[9][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[9][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[9][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[9][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[9][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[9][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[9][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[9][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[9][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[9][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[9][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[9][14];}
	        					            	 
                                               }
	        					             else if (Interface.equalsIgnoreCase("LibraryShuffle"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[10][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[10][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[10][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[10][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[10][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[10][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[10][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[10][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[10][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[10][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[10][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[10][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[10][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[10][14];}
	        					            	 
                                               }
	        					             else if (Interface.equalsIgnoreCase("SettingsShuffle"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[11][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[11][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[11][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[11][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[11][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[11][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[11][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[11][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[11][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[11][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[11][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[11][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[11][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[11][14];}
	        					            	 
                                               }
	        					             
		        					              
	        					             else if (Interface.equalsIgnoreCase("SupportSuffle"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[12][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[12][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[12][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[12][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[12][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[12][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[12][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[12][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[12][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[12][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[12][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[12][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[12][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[12][14];}
	        					            	 
                                              }
		        					              
	        					             else if (Interface.equalsIgnoreCase("Aboutgeo"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[13][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[13][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[13][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[13][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[13][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[13][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[13][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[13][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[13][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[13][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[13][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[13][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[13][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[13][14];}
	        					            	 
                                              }
		        					              
		        					              
	        					             else if (Interface.equalsIgnoreCase("CGeo"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[14][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[14][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[14][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[14][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[14][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[14][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[14][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[14][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[14][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[14][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[14][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[14][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[14][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[14][14];}
	        					            	 
                                              }
		        					              
		        					              
	        					             else if (Interface.equalsIgnoreCase("Geocoaching"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[15][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[15][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[15][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[15][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[15][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[15][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[15][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[15][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[15][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[15][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[15][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[15][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[15][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[15][14];}
	        					            	 
                                              }
		        					              
		        					              
	        					             else if (Interface.equalsIgnoreCase("homeCgeo"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[16][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[16][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[16][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[16][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[16][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[16][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[16][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[16][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[16][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[16][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[16][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[16][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[16][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[16][14];}
	        					            	 
                                              }
		        					              
		        					              
	        					             else if (Interface.equalsIgnoreCase("AboutFarebot"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[17][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[17][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[17][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[17][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[17][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[17][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[17][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[17][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[17][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[17][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[17][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[17][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[17][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[17][14];}
	        					            	 
                                              }
		        					              
		        					              
	        					             else if (Interface.equalsIgnoreCase("Supportedcards"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[18][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[18][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[18][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[18][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[18][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[18][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[18][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[18][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[18][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[18][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[18][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[18][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[18][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[18][14];}
	        					            	 
                                              }
		        					              
		        					              
	        					             else if (Interface.equalsIgnoreCase("AboutSimpleGallery"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[19][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[19][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[19][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[19][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[19][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[19][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[19][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[19][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[19][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[19][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[19][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[19][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[19][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[19][14];}
	        					            	 
                                              }
		        					              
		        					              
	        					             else if (Interface.equalsIgnoreCase("AllfoldersSimpleGallery"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[20][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[20][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[20][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[20][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[20][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[20][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[20][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[20][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[20][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[20][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[20][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[20][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[20][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[20][14];}
	        					            	 
                                              }
		        					              
		        					              
	        					             else if (Interface.equalsIgnoreCase("Gallery"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[21][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[21][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[21][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[21][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[21][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[21][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[21][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[21][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[21][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[21][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[21][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[21][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[21][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[21][14];}
	        					            	 
                                              }
		        					              
	        					             else if (Interface.equalsIgnoreCase("settingsSimpleGallery"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[22][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[22][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[22][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[22][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[22][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[22][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[22][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[22][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[22][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[22][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[22][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[22][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[22][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[22][14];}
	        					            	 
                                              }
		        					              
	        					             else if (Interface.equalsIgnoreCase("record"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[23][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[23][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[23][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[23][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[23][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[23][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[23][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[23][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[23][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[23][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[23][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[23][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[23][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[23][14];}
	        					            	 
                                              }
		        					              
	        					             else if (Interface.equalsIgnoreCase("Telecine"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[24][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[24][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[24][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[24][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[24][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[24][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[24][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[24][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[24][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[24][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[24][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[24][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[24][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[24][14];}
	        					            	 
                                              }
		        					              
	        					             else if (Interface.equalsIgnoreCase("ABoutLibreNews"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[25][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[25][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[25][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[25][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[25][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[25][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[25][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[25][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[25][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[25][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[25][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[25][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[25][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[25][14];}
	        					            	 
                                              }
		        					              
	        					             else if (Interface.equalsIgnoreCase("LibreNews"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[26][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[26][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[26][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[26][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[26][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[26][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[26][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[26][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[26][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[26][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[26][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[26][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[26][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[26][14];}
	        					            	 
                                             }
	        					             else if (Interface.equalsIgnoreCase("appmanager"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[27][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[27][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[27][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[27][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[27][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[27][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[27][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[27][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[27][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[27][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[27][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[27][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[27][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[27][14];}
	        					            	 
                                             }
	        					             else if (Interface.equalsIgnoreCase("grid"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[28][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[28][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[28][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[28][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[28][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[28][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[28][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[28][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[28][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[28][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[28][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[28][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[28][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[28][14];}
	        					            	 
                                             }
	        					             else if (Interface.equalsIgnoreCase("list"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[29][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[29][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[29][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[29][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[29][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[29][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[29][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[29][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[29][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[29][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[29][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[29][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[29][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[29][14];}
	        					            	 
                                             }
	        					             else if (Interface.equalsIgnoreCase("settings"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[30][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[30][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[30][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[30][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[30][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[30][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[30][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[30][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[30][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[30][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[30][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[30][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[30][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[30][14];}
	        					            	 
                                             }
	        					             else if (Interface.equalsIgnoreCase("gettingstarted"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[31][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[31][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[31][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[31][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[31][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[31][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[31][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[31][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[31][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[31][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[31][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[31][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[31][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[31][14];}
	        					            	 
                                             }
	        					             else if (Interface.equalsIgnoreCase("orgzly"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[32][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[32][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[32][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[32][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[32][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[32][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[32][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[32][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[32][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[32][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[32][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[32][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[32][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[32][14];}
	        					            	 
                                             }
	        					             else if (Interface.equalsIgnoreCase("search"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[33][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[33][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[33][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[33][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[33][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[33][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[33][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[33][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[33][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[33][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[33][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[33][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[33][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[33][14];}
	        					            	 
                                             }
	        					             else if (Interface.equalsIgnoreCase("settingsOrgzly"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[34][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[34][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[34][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[34][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[34][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[34][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[34][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[34][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[34][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[34][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[34][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[34][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[34][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[34][14];}
	        					            	 
                                             }
	        					             else if (Interface.equalsIgnoreCase("todo"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[35][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[35][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[35][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[35][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[35][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[35][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[35][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[35][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[35][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[35][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[35][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[35][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[35][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[35][14];}
	        					            	 
                                             }
	        					             else if (Interface.equalsIgnoreCase("AboutNewpipe"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[36][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[36][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[36][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[36][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[36][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[36][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[36][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[36][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[36][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[36][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[36][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[36][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[36][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[36][14];}
	        					            	 
                                             }
	        					             else if (Interface.equalsIgnoreCase("history"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[37][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[37][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[37][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[37][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[37][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[37][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[37][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[37][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[37][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[37][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[37][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[37][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[37][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[37][14];}
	        					            	 
                                             }
	        					             else if (Interface.equalsIgnoreCase("neterror"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[38][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[38][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[38][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[38][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[38][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[38][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[38][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[38][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[38][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[38][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[38][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[38][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[38][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[38][14];}
	        					            	 
                                             }
	        					             else if (Interface.equalsIgnoreCase("play"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[39][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[39][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[39][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[39][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[39][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[39][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[39][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[39][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[39][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[39][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[39][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[39][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[39][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[39][14];}
	        					            	 
                                             }
	        					             else if (Interface.equalsIgnoreCase("search"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[40][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[40][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[40][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[40][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[40][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[40][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[40][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[40][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[40][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[40][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[40][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[40][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[40][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[40][14];}
	        					            	 
                                             }
	        					            
	        					             else if (Interface.equalsIgnoreCase("welcome"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[42][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[42][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[42][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[42][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[42][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[42][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[42][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[42][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[42][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[42][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[42][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[42][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[42][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[42][14];}
	        					            	 
                                             }
		        					              
		        					              
		        					              
		        					              
		        					              
		        					              
	        					            
	        					             else 
	        					                     {  val01 = "0.0";  }
	        					                     
	        					           Metric1 = Double.parseDouble(Val_Metric);
	        					           Metric2 = Double.parseDouble(val01);
	        					           
	        					              

	        					           if ((Problem.equalsIgnoreCase("ILW")||
	        					            		Problem.equalsIgnoreCase("ICM")||
	        					            		Problem.equalsIgnoreCase("OM")||
	        					            		Problem.equalsIgnoreCase("IM"))
	        					            		  && (operateur.equalsIgnoreCase(">=")) && (Metric1 >= Metric2)) {
	        					        	   System.out.println("--------------------------Thats right--------------------------");
		        					        	   System.out.println("(((())))))))"+val01+"    "+Metric+"        "+Interface);
		        					        	     Nbr_prob++  ;
		        					        	     //perfect_rule.add(Perfect);
			                			             
		             			                          if( (Problem.equalsIgnoreCase("ILW")))
		                         	                                {  System.out.println("--------------------------");
		             			                        	             Nbr_Occ_Solution[0] =  Nbr_Occ_Solution[0]+1; }
		                         	                      if(  (Problem.equalsIgnoreCase("ICM")))
		                   	                                        {  Nbr_Occ_Solution[1]= Nbr_Occ_Solution[1]+1 ; }
		                         	                      if( (Problem.equalsIgnoreCase("IM")))
		                   	                                        {   Nbr_Occ_Solution[2] =  Nbr_Occ_Solution[2] + 1 ;}
		                         	                      if((Problem.equalsIgnoreCase("OM")))
		                   	                                          {  Nbr_Occ_Solution[3] =  Nbr_Occ_Solution[3]+1;}
		                         	                     
		                         	                      
		        					           }
	        					           
	        					           
	        					           Metric1 = Double.parseDouble(Val_Metric);
	        					           Metric2 = Double.parseDouble(val01);
	        					           
	        					           if (
	        					        		   (Problem.equalsIgnoreCase("ILW")||
	        					            		Problem.equalsIgnoreCase("ICM")||
	        					            		Problem.equalsIgnoreCase("OM")||
	        					            		Problem.equalsIgnoreCase("IM"))
	        					            		  && (operateur.equalsIgnoreCase("<=")) && (Metric1 <= Metric2)) {
	        					        	   System.out.println("--------------------------Thats right--------------------------");
		        					        	   System.out.println("(((())))))))"+val01+"    "+Metric+"        "+Interface);
		        					        	     Nbr_prob++  ;
		        					        	     //perfect_rule.add(Perfect);
			                			             
		             			                          if( (Problem.equalsIgnoreCase("ILW")))
		                         	                                {  System.out.println("--------------------------");
		             			                        	             Nbr_Occ_Solution[0] =  Nbr_Occ_Solution[0]+1; }
		                         	                      if(  (Problem.equalsIgnoreCase("ICM")))
		                   	                                        {  Nbr_Occ_Solution[1]= Nbr_Occ_Solution[1]+1 ; }
		                         	                      if( (Problem.equalsIgnoreCase("IM")))
		                   	                                        {   Nbr_Occ_Solution[2] =  Nbr_Occ_Solution[2] + 1 ;}
		                         	                      if((Problem.equalsIgnoreCase("OM")))
		                   	                                          {  Nbr_Occ_Solution[3] =  Nbr_Occ_Solution[3]+1;}
		                         	                      
		                         	                      
		        					           }
	        					           
	        					           
	        					         
	        					       
	        					      
	                			       bol = true;
	                			        
		           	                   

	                	}
	                	}
		            k++; 
		            Nbr_Occ_Trace3++;
	                	}
				  // k =1;
				  
	             }}
			  
	}	 
		  
		   	  
		  /////rule4 tetsing
		  for (int i=0; i<IntSolutionType.rules4.size();i++){
			  
			
			  String Problem=IntSolutionType.rules4.get(i).trg ;
			
			  String Metric=IntSolutionType.rules4.get(i).src ;
			  String operateur = IntSolutionType.rules4.get(i).src0 ; 
			  String Val_Metric = IntSolutionType.rules4.get(i).src1;
			 
			  
			  double Metric1 = 0.0 ;
			  double Metric2 = 0.0 ;
			  //System.out.println("///////////////////"+Val_Metric);
			  k =1;
			  boolean bol = false;
			
			         
			  for(int j=0;j<1;j++)
				  
			  {
			  
				  while (k<66 && bol == false ){
					 
					  jxl.Cell cell21 =  sheet.getCell(1, k);
					  String Pro1 =  cell21.getContents();
					  
					
	                	jxl.Cell Valeurs =  sheet.getCell(j, k);
	                	String Val =  Valeurs.getContents();
	                	
	                	if((Val_Metric.equalsIgnoreCase(Val) &&(Problem.equalsIgnoreCase(Pro1))))
	                	{   if (  
               	    		 (Metric=="Regularity"|| Metric=="Layout uniformity" || Metric=="Sequence"|| Metric=="Homogeneity" || Metric=="Simplicity"&& (Problem=="ILW")) ||
               	    		 (Metric=="Cohesion" || Metric=="Layout uniformity" || Metric=="Sequence"|| Metric=="Grouping"&& (Problem=="ICM"))||
               	    		 (Metric=="Balance" || Metric=="Layout uniformity" && (Problem=="IM")) ||
               	    		 (Metric=="Nbelements"|| Metric=="Density"|| Metric=="Economy"|| Metric=="Integrality"&&(Problem=="OM"))
               	    		)
	                		      {  jxl.Cell cell23 =  sheet.getCell(0, k);
	        					     String Interface =  cell23.getContents();
	        					             if (Interface.equalsIgnoreCase("aboutGnu"))
	        					               { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[0][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[0][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[0][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[0][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[0][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[0][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[0][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[0][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[0][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[0][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[0][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[0][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[0][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[0][14];}
	        					            	 
	        					       
	        					            else if (Interface.equalsIgnoreCase("accounts"))
				        					    { 
	        					            	System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[1][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[1][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[1][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[1][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[1][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[1][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[1][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[1][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[1][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[1][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[1][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[1][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[1][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[1][14];}
	        					            	 
		        					                
				        					     }
				        					            	 
				        					
	        					             else if (Interface.equalsIgnoreCase("CreateAccount"))
				        					    { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[2][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[2][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[2][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[2][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[2][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[2][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[2][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[2][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[2][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[2][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[2][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[2][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[2][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[2][14];}
	        					            	 
		        					                
				        					     }

	        					             else if (Interface.equalsIgnoreCase("settingsGnu"))
				        					    { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[3][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[3][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[3][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[3][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[3][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[3][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[3][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[3][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[3][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[3][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[3][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[3][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[3][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[3][14];}
	        					            	 
		        					                
				        					     }
				        					            	 
				        					            	 
	        					             else if (Interface.equalsIgnoreCase("2048-205"))
					        				   { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[4][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[4][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[4][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[4][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[4][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[4][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[4][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[4][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[4][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[4][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[4][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[4][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[4][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[4][14];}
	        					            	 
		        					               
					        				   }
					        					            	
	        					             else if (Interface.equalsIgnoreCase("aboutTisky"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[5][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[5][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[5][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[5][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[5][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[5][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[5][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[5][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[5][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[5][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[5][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[5][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[5][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[5][14];}
	        					            	 
                                                }
	        					             else if (Interface.equalsIgnoreCase("EditYourprofiletisky"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[6][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[6][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[6][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[6][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[6][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[6][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[6][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[6][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[6][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[6][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[6][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[6][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[6][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[6][14];}
	        					            	 
                                               }
	        					             else if (Interface.equalsIgnoreCase("HomeTisky"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[7][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[7][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[7][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[7][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[7][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[7][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[7][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[7][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[7][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[7][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[7][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[7][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[7][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[7][14];}
	        					            	 
                                               }
	        					             else if (Interface.equalsIgnoreCase("ArtistsShuffle"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[8][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[8][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[8][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[8][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[8][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[8][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[8][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[8][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[8][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[8][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[8][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[8][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[8][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[8][14];}
	        					            	 
                                               }
	        					             else if (Interface.equalsIgnoreCase("genresShuffle"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[9][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[9][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[9][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[9][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[9][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[9][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[9][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[9][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[9][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[9][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[9][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[9][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[9][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[9][14];}
	        					            	 
                                               }
	        					             else if (Interface.equalsIgnoreCase("LibraryShuffle"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[10][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[10][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[10][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[10][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[10][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[10][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[10][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[10][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[10][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[10][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[10][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[10][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[10][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[10][14];}
	        					            	 
                                               }
	        					             else if (Interface.equalsIgnoreCase("SettingsShuffle"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[11][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[11][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[11][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[11][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[11][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[11][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[11][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[11][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[11][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[11][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[11][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[11][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[11][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[11][14];}
	        					            	 
                                               }
	        					             
		        					              
	        					             else if (Interface.equalsIgnoreCase("SupportSuffle"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[12][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[12][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[12][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[12][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[12][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[12][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[12][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[12][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[12][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[12][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[12][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[12][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[12][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[12][14];}
	        					            	 
                                              }
		        					              
	        					             else if (Interface.equalsIgnoreCase("Aboutgeo"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[13][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[13][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[13][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[13][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[13][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[13][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[13][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[13][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[13][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[13][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[13][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[13][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[13][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[13][14];}
	        					            	 
                                              }
		        					              
		        					              
	        					             else if (Interface.equalsIgnoreCase("CGeo"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[14][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[14][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[14][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[14][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[14][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[14][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[14][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[14][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[14][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[14][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[14][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[14][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[14][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[14][14];}
	        					            	 
                                              }
		        					              
		        					              
	        					             else if (Interface.equalsIgnoreCase("Geocoaching"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[15][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[15][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[15][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[15][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[15][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[15][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[15][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[15][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[15][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[15][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[15][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[15][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[15][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[15][14];}
	        					            	 
                                              }
		        					              
		        					              
	        					             else if (Interface.equalsIgnoreCase("homeCgeo"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[16][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[16][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[16][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[16][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[16][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[16][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[16][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[16][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[16][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[16][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[16][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[16][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[16][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[16][14];}
	        					            	 
                                              }
		        					              
		        					              
	        					             else if (Interface.equalsIgnoreCase("AboutFarebot"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[17][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[17][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[17][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[17][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[17][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[17][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[17][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[17][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[17][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[17][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[17][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[17][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[17][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[17][14];}
	        					            	 
                                              }
		        					              
		        					              
	        					             else if (Interface.equalsIgnoreCase("Supportedcards"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[18][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[18][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[18][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[18][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[18][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[18][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[18][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[18][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[18][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[18][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[18][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[18][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[18][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[18][14];}
	        					            	 
                                              }
		        					              
		        					              
	        					             else if (Interface.equalsIgnoreCase("AboutSimpleGallery"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[19][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[19][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[19][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[19][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[19][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[19][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[19][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[19][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[19][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[19][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[19][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[19][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[19][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[19][14];}
	        					            	 
                                              }
		        					              
		        					              
	        					             else if (Interface.equalsIgnoreCase("AllfoldersSimpleGallery"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[20][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[20][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[20][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[20][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[20][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[20][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[20][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[20][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[20][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[20][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[20][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[20][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[20][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[20][14];}
	        					            	 
                                              }
		        					              
		        					              
	        					             else if (Interface.equalsIgnoreCase("Gallery"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[21][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[21][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[21][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[21][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[21][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[21][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[21][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[21][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[21][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[21][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[21][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[21][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[21][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[21][14];}
	        					            	 
                                              }
		        					              
	        					             else if (Interface.equalsIgnoreCase("settingsSimpleGallery"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[22][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[22][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[22][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[22][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[22][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[22][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[22][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[22][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[22][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[22][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[22][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[22][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[22][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[22][14];}
	        					            	 
                                              }
		        					              
	        					             else if (Interface.equalsIgnoreCase("record"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[23][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[23][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[23][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[23][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[23][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[23][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[23][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[23][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[23][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[23][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[23][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[23][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[23][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[23][14];}
	        					            	 
                                              }
		        					              
	        					             else if (Interface.equalsIgnoreCase("Telecine"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[24][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[24][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[24][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[24][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[24][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[24][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[24][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[24][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[24][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[24][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[24][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[24][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[24][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[24][14];}
	        					            	 
                                              }
		        					              
	        					             else if (Interface.equalsIgnoreCase("ABoutLibreNews"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[25][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[25][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[25][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[25][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[25][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[25][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[25][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[25][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[25][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[25][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[25][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[25][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[25][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[25][14];}
	        					            	 
                                              }
		        					              
	        					             else if (Interface.equalsIgnoreCase("LibreNews"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[26][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[26][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[26][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[26][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[26][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[26][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[26][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[26][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[26][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[26][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[26][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[26][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[26][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[26][14];}
	        					            	 
                                             }
	        					             else if (Interface.equalsIgnoreCase("appmanager"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[27][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[27][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[27][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[27][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[27][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[27][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[27][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[27][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[27][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[27][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[27][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[27][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[27][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[27][14];}
	        					            	 
                                             }
	        					             else if (Interface.equalsIgnoreCase("grid"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[28][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[28][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[28][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[28][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[28][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[28][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[28][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[28][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[28][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[28][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[28][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[28][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[28][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[28][14];}
	        					            	 
                                             }
	        					             else if (Interface.equalsIgnoreCase("list"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[29][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[29][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[29][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[29][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[29][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[29][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[29][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[29][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[29][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[29][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[29][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[29][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[29][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[29][14];}
	        					            	 
                                             }
	        					             else if (Interface.equalsIgnoreCase("settings"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[30][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[30][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[30][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[30][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[30][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[30][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[30][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[30][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[30][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[30][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[30][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[30][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[30][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[30][14];}
	        					            	 
                                             }
	        					             else if (Interface.equalsIgnoreCase("gettingstarted"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[31][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[31][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[31][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[31][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[31][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[31][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[31][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[31][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[31][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[31][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[31][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[31][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[31][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[31][14];}
	        					            	 
                                             }
	        					             else if (Interface.equalsIgnoreCase("orgzly"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[32][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[32][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[32][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[32][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[32][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[32][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[32][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[32][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[32][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[32][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[32][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[32][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[32][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[32][14];}
	        					            	 
                                             }
	        					             else if (Interface.equalsIgnoreCase("search"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[33][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[33][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[33][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[33][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[33][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[33][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[33][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[33][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[33][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[33][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[33][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[33][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[33][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[33][14];}
	        					            	 
                                             }
	        					             else if (Interface.equalsIgnoreCase("settingsOrgzly"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[34][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[34][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[34][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[34][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[34][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[34][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[34][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[34][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[34][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[34][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[34][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[34][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[34][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[34][14];}
	        					            	 
                                             }
	        					             else if (Interface.equalsIgnoreCase("todo"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[35][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[35][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[35][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[35][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[35][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[35][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[35][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[35][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[35][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[35][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[35][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[35][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[35][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[35][14];}
	        					            	 
                                             }
	        					             else if (Interface.equalsIgnoreCase("AboutNewpipe"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[36][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[36][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[36][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[36][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[36][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[36][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[36][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[36][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[36][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[36][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[36][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[36][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[36][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[36][14];}
	        					            	 
                                             }
	        					             else if (Interface.equalsIgnoreCase("history"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[37][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[37][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[37][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[37][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[37][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[37][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[37][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[37][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[37][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[37][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[37][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[37][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[37][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[37][14];}
	        					            	 
                                             }
	        					             else if (Interface.equalsIgnoreCase("neterror"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[38][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[38][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[38][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[38][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[38][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[38][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[38][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[38][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[38][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[38][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[38][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[38][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[38][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[38][14];}
	        					            	 
                                             }
	        					             else if (Interface.equalsIgnoreCase("play"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[39][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[39][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[39][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[39][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[39][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[39][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[39][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[39][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[39][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[39][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[39][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[39][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[39][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[39][14];}
	        					            	 
                                             }
	        					             else if (Interface.equalsIgnoreCase("search"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[40][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[40][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[40][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[40][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[40][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[40][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[40][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[40][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[40][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[40][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[40][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[40][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[40][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[40][14];}
	        					            	 
                                             }
	        					             
	        					             else if (Interface.equalsIgnoreCase("welcome"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[42][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[42][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[42][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[42][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[42][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[42][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[42][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[42][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[42][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[42][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[42][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[42][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[42][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[42][14];}
	        					            	 
                                             }
		        					              
		        					              
		        					              
		        					              
		        					              
		        					              
	        					            
	        					             else 
	        					                     {  val01 = "0.0";  }
	        					                     
	        					           Metric1 = Double.parseDouble(Val_Metric);
	        					           Metric2 = Double.parseDouble(val01);
	        					           
	        					              

	        					           if ((Problem.equalsIgnoreCase("ILW")||
	        					            		Problem.equalsIgnoreCase("ICM")||
	        					            		Problem.equalsIgnoreCase("OM")||
	        					            		Problem.equalsIgnoreCase("IM"))
	        					            		  && (operateur.equalsIgnoreCase(">=")) && (Metric1 >= Metric2)) {
	        					        	   System.out.println("--------------------------Thats right--------------------------");
		        					        	   System.out.println("(((())))))))"+val01+"    "+Metric+"        "+Interface);
		        					        	     Nbr_prob++  ;
		        					        	     //perfect_rule.add(Perfect);
			                			             
		             			                          if( (Problem.equalsIgnoreCase("ILW")))
		                         	                                {  System.out.println("--------------------------");
		             			                        	             Nbr_Occ_Solution[0] =  Nbr_Occ_Solution[0]+1; }
		                         	                      if(  (Problem.equalsIgnoreCase("ICM")))
		                   	                                        {  Nbr_Occ_Solution[1]= Nbr_Occ_Solution[1]+1 ; }
		                         	                      if( (Problem.equalsIgnoreCase("IM")))
		                   	                                        {   Nbr_Occ_Solution[2] =  Nbr_Occ_Solution[2] + 1 ;}
		                         	                      if((Problem.equalsIgnoreCase("OM")))
		                   	                                          {  Nbr_Occ_Solution[3] =  Nbr_Occ_Solution[3]+1;}
		                         	                     
		                         	                      
		        					           }
	        					           
	        					           
	        					           Metric1 = Double.parseDouble(Val_Metric);
	        					           Metric2 = Double.parseDouble(val01);
	        					           
	        					           if (
	        					        		   (Problem.equalsIgnoreCase("ILW")||
	        					            		Problem.equalsIgnoreCase("ICM")||
	        					            		Problem.equalsIgnoreCase("OM")||
	        					            		Problem.equalsIgnoreCase("IM"))
	        					            		  && (operateur.equalsIgnoreCase("<=")) && (Metric1 <= Metric2)) {
	        					        	   System.out.println("--------------------------Thats right--------------------------");
		        					        	   System.out.println("(((())))))))"+val01+"    "+Metric+"        "+Interface);
		        					        	     Nbr_prob++  ;
		        					        	     //perfect_rule.add(Perfect);
			                			             
		             			                          if( (Problem.equalsIgnoreCase("ILW")))
		                         	                                {  System.out.println("--------------------------");
		             			                        	             Nbr_Occ_Solution[0] =  Nbr_Occ_Solution[0]+1; }
		                         	                      if(  (Problem.equalsIgnoreCase("ICM")))
		                   	                                        {  Nbr_Occ_Solution[1]= Nbr_Occ_Solution[1]+1 ; }
		                         	                      if( (Problem.equalsIgnoreCase("IM")))
		                   	                                        {   Nbr_Occ_Solution[2] =  Nbr_Occ_Solution[2] + 1 ;}
		                         	                      if((Problem.equalsIgnoreCase("OM")))
		                   	                                          {  Nbr_Occ_Solution[3] =  Nbr_Occ_Solution[3]+1;}
		                         	                      
		                         	                      
		        					           }
	        					           
	        					           
	        					         
	        					       
	        					      
	                			       bol = true;
	                			        
		           	                   

	                	}
	                	}
		            k++; 
		            Nbr_Occ_Trace4++;
	                	}
				  // k =1;
				  
	             }}
			  
	}	 
		  
		    
		  /////rule5 testing
		  for (int i=0; i<IntSolutionType.rules5.size();i++){
			  
			
			  String Problem=IntSolutionType.rules5.get(i).trg ;
			
			  String Metric=IntSolutionType.rules5.get(i).src ;
			  String operateur = IntSolutionType.rules5.get(i).src0 ; 
			  String Val_Metric = IntSolutionType.rules5.get(i).src1;
			 
			  
			  double Metric1 = 0.0 ;
			  double Metric2 = 0.0 ;
			  //System.out.println("///////////////////"+Val_Metric);
			  k =1;
			  boolean bol = false;
			
			         
			  for(int j=0;j<1;j++)
				  
			  {
			  
				  while (k<66 && bol == false ){
					 
					  jxl.Cell cell21 =  sheet.getCell(1, k);
					  String Pro1 =  cell21.getContents();
					  
					
	                	jxl.Cell Valeurs =  sheet.getCell(j, k);
	                	String Val =  Valeurs.getContents();
	                	
	                	if((Val_Metric.equalsIgnoreCase(Val) &&(Problem.equalsIgnoreCase(Pro1))))
	                	{   if (  
               	    		 (Metric=="Regularity"|| Metric=="Layout uniformity" || Metric=="Sequence"|| Metric=="Homogeneity" || Metric=="Simplicity"&& (Problem=="ILW")) ||
               	    		 (Metric=="Cohesion" || Metric=="Layout uniformity" || Metric=="Sequence"|| Metric=="Grouping"&& (Problem=="ICM"))||
               	    		 (Metric=="Balance" || Metric=="Layout uniformity" && (Problem=="IM")) ||
               	    		 (Metric=="Nbelements"|| Metric=="Density"|| Metric=="Economy"|| Metric=="Integrality"&&(Problem=="OM"))
               	    		)
	                		      {  jxl.Cell cell23 =  sheet.getCell(0, k);
	        					     String Interface =  cell23.getContents();
	        					             if (Interface.equalsIgnoreCase("aboutGnu"))
	        					               { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[0][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[0][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[0][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[0][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[0][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[0][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[0][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[0][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[0][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[0][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[0][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[0][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[0][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[0][14];}
	        					            	 
	        					       
	        					            else if (Interface.equalsIgnoreCase("accounts"))
				        					    { 
	        					            	System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[1][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[1][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[1][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[1][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[1][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[1][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[1][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[1][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[1][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[1][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[1][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[1][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[1][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[1][14];}
	        					            	 
		        					                
				        					     }
				        					            	 
				        					
	        					             else if (Interface.equalsIgnoreCase("CreateAccount"))
				        					    { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[2][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[2][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[2][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[2][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[2][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[2][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[2][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[2][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[2][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[2][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[2][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[2][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[2][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[2][14];}
	        					            	 
		        					                
				        					     }

	        					             else if (Interface.equalsIgnoreCase("settingsGnu"))
				        					    { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[3][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[3][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[3][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[3][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[3][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[3][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[3][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[3][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[3][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[3][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[3][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[3][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[3][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[3][14];}
	        					            	 
		        					                
				        					     }
				        					            	 
				        					            	 
	        					             else if (Interface.equalsIgnoreCase("2048-205"))
					        				   { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[4][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[4][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[4][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[4][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[4][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[4][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[4][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[4][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[4][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[4][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[4][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[4][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[4][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[4][14];}
	        					            	 
		        					               
					        				   }
					        					            	
	        					             else if (Interface.equalsIgnoreCase("aboutTisky"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[5][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[5][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[5][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[5][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[5][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[5][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[5][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[5][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[5][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[5][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[5][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[5][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[5][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[5][14];}
	        					            	 
                                                }
	        					             else if (Interface.equalsIgnoreCase("EditYourprofiletisky"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[6][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[6][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[6][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[6][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[6][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[6][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[6][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[6][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[6][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[6][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[6][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[6][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[6][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[6][14];}
	        					            	 
                                               }
	        					             else if (Interface.equalsIgnoreCase("HomeTisky"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[7][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[7][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[7][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[7][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[7][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[7][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[7][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[7][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[7][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[7][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[7][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[7][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[7][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[7][14];}
	        					            	 
                                               }
	        					             else if (Interface.equalsIgnoreCase("ArtistsShuffle"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[8][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[8][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[8][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[8][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[8][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[8][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[8][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[8][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[8][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[8][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[8][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[8][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[8][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[8][14];}
	        					            	 
                                               }
	        					             else if (Interface.equalsIgnoreCase("genresShuffle"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[9][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[9][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[9][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[9][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[9][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[9][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[9][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[9][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[9][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[9][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[9][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[9][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[9][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[9][14];}
	        					            	 
                                               }
	        					             else if (Interface.equalsIgnoreCase("LibraryShuffle"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[10][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[10][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[10][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[10][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[10][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[10][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[10][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[10][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[10][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[10][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[10][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[10][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[10][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[10][14];}
	        					            	 
                                               }
	        					             else if (Interface.equalsIgnoreCase("SettingsShuffle"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[11][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[11][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[11][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[11][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[11][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[11][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[11][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[11][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[11][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[11][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[11][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[11][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[11][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[11][14];}
	        					            	 
                                               }
	        					             
		        					              
	        					             else if (Interface.equalsIgnoreCase("SupportSuffle"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[12][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[12][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[12][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[12][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[12][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[12][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[12][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[12][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[12][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[12][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[12][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[12][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[12][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[12][14];}
	        					            	 
                                              }
		        					              
	        					             else if (Interface.equalsIgnoreCase("Aboutgeo"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[13][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[13][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[13][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[13][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[13][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[13][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[13][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[13][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[13][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[13][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[13][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[13][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[13][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[13][14];}
	        					            	 
                                              }
		        					              
		        					              
	        					             else if (Interface.equalsIgnoreCase("CGeo"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[14][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[14][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[14][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[14][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[14][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[14][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[14][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[14][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[14][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[14][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[14][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[14][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[14][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[14][14];}
	        					            	 
                                              }
		        					              
		        					              
	        					             else if (Interface.equalsIgnoreCase("Geocoaching"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[15][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[15][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[15][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[15][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[15][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[15][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[15][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[15][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[15][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[15][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[15][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[15][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[15][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[15][14];}
	        					            	 
                                              }
		        					              
		        					              
	        					             else if (Interface.equalsIgnoreCase("homeCgeo"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[16][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[16][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[16][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[16][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[16][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[16][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[16][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[16][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[16][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[16][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[16][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[16][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[16][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[16][14];}
	        					            	 
                                              }
		        					              
		        					              
	        					             else if (Interface.equalsIgnoreCase("AboutFarebot"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[17][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[17][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[17][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[17][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[17][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[17][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[17][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[17][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[17][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[17][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[17][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[17][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[17][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[17][14];}
	        					            	 
                                              }
		        					              
		        					              
	        					             else if (Interface.equalsIgnoreCase("Supportedcards"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[18][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[18][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[18][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[18][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[18][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[18][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[18][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[18][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[18][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[18][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[18][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[18][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[18][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[18][14];}
	        					            	 
                                              }
		        					              
		        					              
	        					             else if (Interface.equalsIgnoreCase("AboutSimpleGallery"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[19][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[19][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[19][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[19][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[19][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[19][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[19][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[19][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[19][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[19][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[19][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[19][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[19][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[19][14];}
	        					            	 
                                              }
		        					              
		        					              
	        					             else if (Interface.equalsIgnoreCase("AllfoldersSimpleGallery"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[20][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[20][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[20][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[20][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[20][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[20][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[20][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[20][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[20][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[20][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[20][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[20][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[20][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[20][14];}
	        					            	 
                                              }
		        					              
		        					              
	        					             else if (Interface.equalsIgnoreCase("Gallery"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[21][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[21][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[21][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[21][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[21][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[21][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[21][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[21][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[21][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[21][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[21][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[21][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[21][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[21][14];}
	        					            	 
                                              }
		        					              
	        					             else if (Interface.equalsIgnoreCase("settingsSimpleGallery"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[22][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[22][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[22][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[22][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[22][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[22][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[22][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[22][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[22][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[22][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[22][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[22][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[22][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[22][14];}
	        					            	 
                                              }
		        					              
	        					             else if (Interface.equalsIgnoreCase("record"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[23][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[23][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[23][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[23][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[23][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[23][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[23][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[23][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[23][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[23][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[23][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[23][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[23][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[23][14];}
	        					            	 
                                              }
		        					              
	        					             else if (Interface.equalsIgnoreCase("Telecine"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[24][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[24][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[24][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[24][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[24][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[24][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[24][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[24][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[24][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[24][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[24][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[24][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[24][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[24][14];}
	        					            	 
                                              }
		        					              
	        					             else if (Interface.equalsIgnoreCase("ABoutLibreNews"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[25][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[25][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[25][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[25][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[25][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[25][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[25][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[25][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[25][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[25][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[25][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[25][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[25][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[25][14];}
	        					            	 
                                              }
		        					              
	        					             else if (Interface.equalsIgnoreCase("LibreNews"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[26][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[26][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[26][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[26][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[26][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[26][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[26][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[26][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[26][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[26][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[26][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[26][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[26][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[26][14];}
	        					            	 
                                             }
	        					             else if (Interface.equalsIgnoreCase("appmanager"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[27][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[27][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[27][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[27][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[27][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[27][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[27][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[27][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[27][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[27][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[27][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[27][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[27][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[27][14];}
	        					            	 
                                             }
	        					             else if (Interface.equalsIgnoreCase("grid"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[28][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[28][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[28][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[28][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[28][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[28][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[28][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[28][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[28][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[28][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[28][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[28][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[28][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[28][14];}
	        					            	 
                                             }
	        					             else if (Interface.equalsIgnoreCase("list"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[29][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[29][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[29][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[29][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[29][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[29][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[29][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[29][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[29][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[29][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[29][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[29][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[29][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[29][14];}
	        					            	 
                                             }
	        					             else if (Interface.equalsIgnoreCase("settings"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[30][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[30][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[30][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[30][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[30][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[30][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[30][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[30][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[30][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[30][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[30][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[30][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[30][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[30][14];}
	        					            	 
                                             }
	        					             else if (Interface.equalsIgnoreCase("gettingstarted"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[31][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[31][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[31][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[31][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[31][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[31][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[31][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[31][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[31][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[31][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[31][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[31][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[31][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[31][14];}
	        					            	 
                                             }
	        					             else if (Interface.equalsIgnoreCase("orgzly"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[32][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[32][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[32][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[32][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[32][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[32][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[32][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[32][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[32][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[32][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[32][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[32][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[32][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[32][14];}
	        					            	 
                                             }
	        					             else if (Interface.equalsIgnoreCase("search"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[33][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[33][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[33][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[33][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[33][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[33][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[33][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[33][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[33][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[33][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[33][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[33][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[33][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[33][14];}
	        					            	 
                                             }
	        					             else if (Interface.equalsIgnoreCase("settingsOrgzly"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[34][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[34][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[34][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[34][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[34][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[34][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[34][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[34][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[34][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[34][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[34][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[34][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[34][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[34][14];}
	        					            	 
                                             }
	        					             else if (Interface.equalsIgnoreCase("todo"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[35][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[35][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[35][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[35][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[35][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[35][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[35][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[35][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[35][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[35][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[35][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[35][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[35][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[35][14];}
	        					            	 
                                             }
	        					             else if (Interface.equalsIgnoreCase("AboutNewpipe"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[36][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[36][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[36][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[36][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[36][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[36][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[36][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[36][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[36][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[36][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[36][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[36][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[36][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[36][14];}
	        					            	 
                                             }
	        					             else if (Interface.equalsIgnoreCase("history"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[37][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[37][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[37][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[37][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[37][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[37][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[37][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[37][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[37][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[37][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[37][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[37][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[37][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[37][14];}
	        					            	 
                                             }
	        					             else if (Interface.equalsIgnoreCase("neterror"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[38][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[38][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[38][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[38][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[38][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[38][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[38][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[38][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[38][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[38][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[38][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[38][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[38][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[38][14];}
	        					            	 
                                             }
	        					             else if (Interface.equalsIgnoreCase("play"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[39][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[39][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[39][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[39][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[39][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[39][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[39][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[39][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[39][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[39][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[39][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[39][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[39][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[39][14];}
	        					            	 
                                             }
	        					             else if (Interface.equalsIgnoreCase("search"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[40][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[40][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[40][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[40][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[40][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[40][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[40][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[40][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[40][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[40][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[40][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[40][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[40][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[40][14];}
	        					            	 
                                             }
	        					            
	        					             else if (Interface.equalsIgnoreCase("welcome"))
						        			  { 
	        					            	 System.out.println("****************************");
	        					            	  if (Metric=="Regularity") {  val01 =  Interface_Metric[42][1];}
	        					            	  if (Metric=="Grouping")   {val01 =  Interface_Metric[42][2];}
	        					                  if (Metric=="Sequence")   {  val01 =  Interface_Metric[42][3];}
	        					                  if (Metric=="Simplicity") {  val01 =  Interface_Metric[42][4];}
	        					                  if (Metric=="Density")    {  val01 =  Interface_Metric[42][5];} 
		        					              if (Metric=="Unity")      {  val01 =  Interface_Metric[42][6];}
	        					            	  if (Metric=="Homogeneity") {  val01 =   Interface_Metric[42][7];}
	        					                  if (Metric=="Economy") {  val01 =   Interface_Metric[42][8];}
	        					                  if (Metric=="Balance") {  val01 =  Interface_Metric[42][9];}
	        					            	  if (Metric=="Layout uniformity")   {  val01 =  Interface_Metric[42][10];}
	        					                  if (Metric=="Cohesion")   {  val01 =  Interface_Metric[42][11];}
	        					                  if (Metric=="Nbelements") {  val01 =  Interface_Metric[42][12];}
	        					                  if (Metric=="Clarity")    {  val01 =  Interface_Metric[42][13];} 
		        					              if (Metric=="Integrality")      {  val01 =  Interface_Metric[42][14];}
	        					            	 
                                             }
		        					              
		        					              
		        					              
		        					              
		        					              
		        					              
	        					            
	        					             else 
	        					                     {  val01 = "0.0";  }
	        					                     
	        					           Metric1 = Double.parseDouble(Val_Metric);
	        					           Metric2 = Double.parseDouble(val01);
	        					           
	        					              

	        					           if ((Problem.equalsIgnoreCase("ILW")||
	        					            		Problem.equalsIgnoreCase("ICM")||
	        					            		Problem.equalsIgnoreCase("OM")||
	        					            		Problem.equalsIgnoreCase("IM"))
	        					            		  && (operateur.equalsIgnoreCase(">=")) && (Metric1 >= Metric2)) {
	        					        	   System.out.println("--------------------------Thats right--------------------------");
		        					        	   System.out.println("(((())))))))"+val01+"    "+Metric+"        "+Interface);
		        					        	     Nbr_prob++  ;
		        					        	     //perfect_rule.add(Perfect);
			                			             
		             			                          if( (Problem.equalsIgnoreCase("ILW")))
		                         	                                {  System.out.println("--------------------------");
		             			                        	             Nbr_Occ_Solution[0] =  Nbr_Occ_Solution[0]+1; }
		                         	                      if(  (Problem.equalsIgnoreCase("ICM")))
		                   	                                        {  Nbr_Occ_Solution[1]= Nbr_Occ_Solution[1]+1 ; }
		                         	                      if( (Problem.equalsIgnoreCase("IM")))
		                   	                                        {   Nbr_Occ_Solution[2] =  Nbr_Occ_Solution[2] + 1 ;}
		                         	                      if((Problem.equalsIgnoreCase("OM")))
		                   	                                          {  Nbr_Occ_Solution[3] =  Nbr_Occ_Solution[3]+1;}
		                         	                     
		                         	                      
		        					           }
	        					           
	        					           
	        					           Metric1 = Double.parseDouble(Val_Metric);
	        					           Metric2 = Double.parseDouble(val01);
	        					           
	        					           if (
	        					        		   (Problem.equalsIgnoreCase("ILW")||
	        					            		Problem.equalsIgnoreCase("ICM")||
	        					            		Problem.equalsIgnoreCase("OM")||
	        					            		Problem.equalsIgnoreCase("IM"))
	        					            		  && (operateur.equalsIgnoreCase("<=")) && (Metric1 <= Metric2)) {
	        					        	   System.out.println("--------------------------Thats right--------------------------");
		        					        	   System.out.println("(((())))))))"+val01+"    "+Metric+"        "+Interface);
		        					        	     Nbr_prob++  ;
		        					        	     //perfect_rule.add(Perfect);
			                			             
		             			                          if( (Problem.equalsIgnoreCase("ILW")))
		                         	                                {  System.out.println("--------------------------");
		             			                        	             Nbr_Occ_Solution[0] =  Nbr_Occ_Solution[0]+1; }
		                         	                      if(  (Problem.equalsIgnoreCase("ICM")))
		                   	                                        {  Nbr_Occ_Solution[1]= Nbr_Occ_Solution[1]+1 ; }
		                         	                      if( (Problem.equalsIgnoreCase("IM")))
		                   	                                        {   Nbr_Occ_Solution[2] =  Nbr_Occ_Solution[2] + 1 ;}
		                         	                      if((Problem.equalsIgnoreCase("OM")))
		                   	                                          {  Nbr_Occ_Solution[3] =  Nbr_Occ_Solution[3]+1;}
		                         	                      
		                         	                      
		        					           }
	        					           
	        					           
	        					         
	        					       
	        					      
	                			       bol = true;
	                			        
		           	                   

	                	}
	                	}
		            k++; 
		            Nbr_Occ_Trace5++;
	                	}
				  // k =1;
				  
	             }}
			  
	}	 
		  
		    
		  
		  
		  
		  
		  double fit=0.0;
		  double fitT=0.0;
		  
		 /* for(int i=0 ;i<Nbr_Occ_Solution.length;i++){
			 
			  System.out.println("le problem dans la solution "+i+" repeter "+Nbr_Occ_Solution[i]);
				 fit=(int) (fit + (Nbr_Occ_Solution[i])); 
			  }*/
		  for(int i=0 ;i<Nbr_Occ_Trace.length;i++){
				 System.out.println("le problem dans le trace "+i+" repeter "+Nbr_Occ_Trace[i]);
				  System.out.println("le problem dans la solution "+i+" repeter "+Nbr_Occ_Solution[i]);
					fit =(fit + (Nbr_Occ_Solution[i] / Nbr_Occ_Trace[i])); 
				  }
		  
		  double fit1=Nbr_Occ_Trace1/IntSolutionType.rules.size();
			double fit2=Nbr_Occ_Trace2/IntSolutionType.rules2.size(); 
			double fit3=Nbr_Occ_Trace3/IntSolutionType.rules3.size(); 
			double fit4=Nbr_Occ_Trace4/IntSolutionType.rules4.size(); 
			double fit5=Nbr_Occ_Trace5/IntSolutionType.rules5.size(); 
			fitT=(fit1+fit2+fit3+fit4+fit5+fit)/4 ;
			fitnes2=fitT;
			
		   double fitness2 = fitnes2;
		   System.out.println(" fit2 "+ fitness2);
		   return fitness2= ((double)((int)( fitness2*100))/100);
		
	    //System.out.println(" Resultat2 "+ fitness2);
		// System.out.println("Ma liste "+perfect_rule);
		  //this.individual_NbPro= fitness2;   //Nbr_prob;
		  //System.out.println("@@@@@@@@@"+Nbr_prob);
		 
		
	}
	public static void main(String[] args) throws FileNotFoundException,
	IOException, ClassNotFoundException {
		
		
	Input r = new Input ();
		
	    int min_rules_size = 10;
		int max_rules_size = 20;
		int value = 1;
		rules R = new rules ();
		R.create_rules2(r, min_rules_size);
		sol.addAll(R.create_rules2(r, min_rules_size));
		R.Mymutation(sol, value);
		parent1.addAll(R.create_rules2(r, min_rules_size));
		parent2.addAll(R.create_rules2(r, min_rules_size));
		R.MyCrossover(parent1, parent2 , min_rules_size);
		
	/*	Input r = new Input ();
		int value = 1;
		int value2 = 20 ;
		int  min_rules_size = 20;
		int  max_rules_size = 30 ;
		//String solution = null;
		//Adapt_Interface prob= new Adapt_Interface(solution);
		//IntSolutionType t=new IntSolutionType(prob);
		Rule[] Rules = null;
		for( int i= 0 ; i< IntSolutionType.rules.length ; i++)
		{Rules[i]=IntSolutionType.rules[i];}
		ArrayList <Rule> parent1 = new ArrayList <Rule>();
		ArrayList <Rule> parent2 = new ArrayList <Rule>();
	    
		MySolution S = new  MySolution ();
		
		S.create_rule1(r, min_rules_size);
		S.create_rule2(r, min_rules_size);
		S.create_rule3(r, min_rules_size);
		S.create_rule4(r, min_rules_size);
		S.create_rule5(r, min_rules_size);
		
		System.out.println("fitness values"+S.fitness_2());
		   
		
		
		
		for(int i = 0 ; i< 5 ;i++)
		{parent1.addAll(S.create_rule1(r, min_rules_size));}
		for(int i = 0 ; i< 5 ;i++)
		{System.out.println("parent 1 : "+parent1.get(i).rule_text);
		//S.Mymutation(value, parent1.get(value));
		}
		
		for(int i = 0 ; i< 5 ;i++)
		{parent1.addAll(S.create_rule2(r,min_rules_size));}
		for(int i = 0 ; i< 5 ;i++)
		{System.out.println("parent 1 : "+parent1.get(i).rule_text);
		//S.Mymutation(value, parent1.get(value));
		}
		for(int i = 0 ; i< 5 ;i++)
		{parent1.addAll(S.create_rule3(r,min_rules_size));}
		for(int i = 0 ; i< 5 ;i++)
		{System.out.println("parent 1 : "+parent1.get(i).rule_text);
		//S.Mymutation(value, parent1.get(value));
		}
		
		for(int i = 0 ; i< 5 ;i++)
		{parent1.addAll(S.create_rule4(r,min_rules_size));}
		for(int i = 0 ; i< 5 ;i++)
		{System.out.println("parent 1 : "+parent1.get(i).rule_text);
		//S.Mymutation(value, parent1.get(value));
		}
		
		
		for(int i = 0 ; i< 5 ;i++)
		{parent1.addAll(S.create_rule5(r,min_rules_size));}
		for(int i = 0 ; i< 5 ;i++)
		{System.out.println("parent 1 : "+parent1.get(i).rule_text);
		//S.Mymutation(value, parent1.get(value));
		}
		
		
		
		
		
		
		
		
		for(int i = 0 ; i< 5 ;i++)
		{parent2.addAll(S.create_rule1(r,min_rules_size));}
		for(int i = 0 ; i< 5 ;i++)
		{System.out.println("parent 2 : "+parent2.get(i).rule_text);}
		//S.create_solution(r, value2);
		
		
		
		//S.fitness_1();
		S.MyCrossover(parent1, parent2, min_rules_size);
		//S. SolutionSize ( min_rules_size , max_rules_size );
*/	}
}
