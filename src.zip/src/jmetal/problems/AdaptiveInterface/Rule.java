 package jmetal.problems.AdaptiveInterface;

import java.lang.*;
import java.util.Random;

public class Rule
{ 
  
	public String src; // metric
    public  String src0; //operateur
    public String src1;//metric value
    public String trg;//problem
    public String rule_text ;
    public Rule()
    { 
     
       rule_text = new String();
    }
    
    public void print_rule( )
    { Random number_generator = new Random();
    	
        String temp = new String("IF (");
        temp = temp.concat(src); // name of metric
        temp = temp.concat(src0); // operteur
        temp = temp.concat(src1); // valeur de matric
        temp = temp.concat(")");
        
        temp = temp.concat(" THEN (");
        temp = temp.concat(trg);
        temp = temp.concat(")");
        rule_text = temp ;
    }

   
	}



