 package jmetal.problems.AdaptiveInterface;

import java.lang.*;
import java.util.Random;

public class Rule3m
{ 
  
	public String src; // metric
    public  String src0; //operateur
    public String src1;//metric value
    public String src2; //and or
    public String src3;
    public String src4;
    public String src5; 
    public String src6; //and or
    public String src7;
    public String src8;
    public String src9; 
    public String trg;//problem
    public String rule_text ;
    public Rule3m()
    { 
     
       rule_text = new String();
    }
    
    public void print_rule( )
    { Random number_generator = new Random();
    	
        String temp = new String("IF (");
        temp = temp.concat(src); // name of metric
        temp = temp.concat(src0); // operteur
        temp = temp.concat(src1); // valeur de matric
        temp = temp.concat(src2); //And OR
        temp = temp.concat(src3); // name of metric
        temp = temp.concat(src4); // operteur
        temp = temp.concat(src5); // valeur de matric
        temp = temp.concat(src6); //And OR
        temp = temp.concat(src7); // name of metric
        temp = temp.concat(src8); // operteur
        temp = temp.concat(src9); // valeur de matric
        temp = temp.concat(") THEN (");
        temp = temp.concat(trg);
        temp = temp.concat(")");
        rule_text = temp ;
    }

   
	}



