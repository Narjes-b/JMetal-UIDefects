 package jmetal.problems.AdaptiveInterface;

import java.lang.*;
import java.util.Random;

public class Rule5m
{ 
  
	public String src; // metric
    public  String src0; //operateur
    public String src1;//metric value
    public String src2; //and or
    public String src3;
    public String src4;
    public String src5; 
    public String src6; //and or
    public String src7;
    public String src8;
    public String src9; 
    public String src10; //and or
    public String src11;
    public String src12;
    public String src13;
    public String src14; //and or
    public String src15;
    public String src16;
    public String src17; 
    public String trg;//problem
    public String rule_text ;
    public Rule5m()
    { 
     
       rule_text = new String();
    }
    
    public void print_rule( )
    { Random number_generator = new Random();
    	
        String temp = new String("IF (");
        temp = temp.concat(src); // name of metric
        temp = temp.concat(src0); // operteur
        temp = temp.concat(src1); // valeur de matric
        temp = temp.concat(src2); //And OR
        temp = temp.concat(src3); // name of metric
        temp = temp.concat(src4); // operteur
        temp = temp.concat(src5); // valeur de matric
        temp = temp.concat(src6); //And OR
        temp = temp.concat(src7); // name of metric
        temp = temp.concat(src8); // operteur
        temp = temp.concat(src9); // valeur de matric
        temp = temp.concat(src10); //And OR
        temp = temp.concat(src11); // name of metric
        temp = temp.concat(src12); // operteur
        temp = temp.concat(src13); // valeur de matric
        temp = temp.concat(src14); //And OR
        temp = temp.concat(src15); // name of metric
        temp = temp.concat(src16); // operteur
        temp = temp.concat(src17); // valeur de matric
        temp = temp.concat(") THEN (");
        temp = temp.concat(trg);
        temp = temp.concat(")");
        rule_text = temp ;
    }

   
	}



