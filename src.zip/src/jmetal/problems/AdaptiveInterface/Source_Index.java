 package jmetal.problems.AdaptiveInterface;


import java.util.Random;

public class Source_Index {
	static Random number_generator = new Random(); 
	
	public static int index_Metrics()
	{
		 int source_index=  number_generator.nextInt(Input.Metrics().length);
		return source_index ;
	}
	public static int index_Operator()
	{
		 int source_index0=  number_generator.nextInt(Input.Operator().length);
		return source_index0 ;
	}
	public static int index_AndOr()
	{
		 int source_index1=  number_generator.nextInt(Input.AndOr().length);
		return source_index1 ;
	}
	public static int index_Problem()
	{
		 int target_index=  number_generator.nextInt(Input.Problem().length);
		return target_index ;
	}
}
